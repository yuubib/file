# 图标文件

这个目录包含小程序所需的图标文件。您需要添加以下图标：

## 底部导航栏图标
- wardrobe.png - 衣橱图标（未选中状态）
- wardrobe_selected.png - 衣橱图标（选中状态）
- match.png - 搭配图标（未选中状态）
- match_selected.png - 搭配图标（选中状态）
- calendar.png - 日历图标（未选中状态）
- calendar_selected.png - 日历图标（选中状态）
- inspiration.png - 灵感图标（未选中状态）
- inspiration_selected.png - 灵感图标（选中状态）
- settings.png - 设置图标（未选中状态）
- settings_selected.png - 设置图标（选中状态）

## 功能图标
- grid.png - 网格视图图标（切换到平铺视图）
- grid_view.png - 网格视图模式图标
- list_view.png - 列表视图模式图标
- scan.png - 扫描图标
- more.png - 更多选项图标
- edit_active.png - 编辑模式激活图标
- settings_category.png - 类别设置图标
- filter.png - 筛选图标
- settings_view.png - 视图设置图标
- back.png - 返回图标
- clock.png - 时钟图标（日历页面）
- export.png - 导出图标（日历页面）
- weather.png - 天气图标（日历页面）
- edit.png - 编辑图标
- delete.png - 删除图标
- share.png - 分享图标

## 设置页面图标
- stats.png - 衣橱统计图标
- member.png - 会员图标
- backup.png - 数据备份图标
- season.png - 季节限定图标
- wardrobe_manage.png - 管理衣橱图标
- options.png - 管理选项图标
- size.png - 身材尺码图标
- trash.png - 回收站图标
- modules.png - 功能模块图标
- appearance.png - 外观图标
- help.png - 帮助中心图标
- feedback.png - 问题反馈图标
- wechat.png - 微信公众号图标

请确保所有图标都是透明背景的PNG文件，并且大小适合小程序使用（建议48x48像素）。 