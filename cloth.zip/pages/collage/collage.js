Page({
  data: {
    title: '拼图',
    activeTab: 'background', // 当前激活的选项卡: background, item, photo, text, material
    backgrounds: [],
    clothingItems: [],
    selectedItems: [], // 已添加到画布的元素
    currentItemId: null, // 当前选中元素ID
    currentOperation: null, // 当前操作: move, scale, rotate
    canvasBackgroundColor: '#ffffff', // 默认背景颜色为白色
    canvasSize: 300, // 画布的大小（默认值，将在onReady中更新）
    categoryId: '' // 存储从index页面传来的分类ID
  },

  onLoad: function (options) {
    // 接收从index页面传来的分类ID
    if (options.categoryId) {
      this.setData({
        categoryId: options.categoryId
      });
    }

    // 加载背景和衣物数据
    this.loadBackgrounds();
    this.loadClothingItems();
  },

  onReady: function () {
    // 获取画布的实际尺寸
    const query = wx.createSelectorQuery();
    query.select('.canvas-area').boundingClientRect();
    query.exec((res) => {
      if (res && res[0]) {
        this.setData({
          canvasSize: res[0].width
        });
      }
    });
  },

  // 返回上一页
  navigateBack: function () {
    wx.navigateBack();
  },

  // 加载背景数据
  loadBackgrounds: function () {
    // 使用背景颜色
    const backgrounds = [
      { id: 1, color: '#ffffff' }, // 白色
      { id: 2, color: '#f5f5f5' }, // 浅灰色
      { id: 3, color: '#e6e6e6' }, // 灰色
      { id: 4, color: '#ffebee' }, // 浅红色
      { id: 5, color: '#e8f5e9' }, // 浅绿色
      { id: 6, color: '#e3f2fd' }, // 浅蓝色
      { id: 7, color: '#fff8e1' }, // 浅黄色
      { id: 8, color: '#f3e5f5' }  // 浅紫色
    ];

    this.setData({ backgrounds });
  },

  // 加载衣物数据
  loadClothingItems: function () {
    const db = getApp().globalData.db;

    wx.showLoading({ title: '加载中...' });

    db.collection('clothes').get().then(res => {
      this.setData({ clothingItems: res.data });
      wx.hideLoading();
    }).catch(err => {
      wx.hideLoading();

      // 如果获取失败，使用本地存储的数据
      const clothItems = wx.getStorageSync('clothItems') || [];
      this.setData({ clothingItems: clothItems });

      wx.showToast({ title: '使用本地数据', icon: 'none' });
    });
  },

  // 切换底部选项卡
  switchTab: function (e) {
    const tab = e.currentTarget.dataset.tab;

    // 如果点击的是"单品"选项卡，则导航到单品选择页面
    if (tab === 'item') {
      wx.navigateTo({ url: '../item_select/item_select' });
      return;
    }

    this.setData({ activeTab: tab });
  },

  // 添加背景到画布
  addBackground: function (e) {
    const backgroundId = e.currentTarget.dataset.id;
    const background = this.data.backgrounds.find(bg => bg.id === backgroundId);

    if (background) {
      this.setData({ canvasBackgroundColor: background.color });
    }
  },

  // 添加已选择的衣物到画布
  addSelectedClothingItems: function (selectedClothes) {
    if (!selectedClothes || selectedClothes.length === 0) return;

    // 计算画布中心位置
    const canvasCenter = this.data.canvasSize / 2;
    const itemSize = this.data.canvasSize / 4; // 项目默认大小为画布的1/4

    // 将所有选中的衣物添加到画布
    const newItems = selectedClothes.map((item, index) => {
      // 根据索引稍微错开位置，避免堆叠
      const offsetX = index * 10;
      const offsetY = index * 10;

      return {
        id: `item_${Date.now()}_${index}`,
        type: 'clothing',
        image: item.image,
        x: (canvasCenter - (itemSize / 2)) + offsetX, // 错开位置
        y: (canvasCenter - (itemSize / 2)) + offsetY, // 错开位置
        width: itemSize,
        height: itemSize,
        rotation: 0,
        zIndex: this.data.selectedItems.length + index + 1
      };
    });

    // 添加到已选元素中
    const selectedItems = [...this.data.selectedItems, ...newItems];
    this.setData({ selectedItems, activeTab: 'background' });
  },

  // 添加衣物到画布
  addClothingItem: function (e) {
    const itemId = e.currentTarget.dataset.id;
    const item = this.data.clothingItems.find(item => item._id === itemId);

    if (item) {
      this.addItemWithImage(item.image, 'clothing');
    }
  },

  // 添加照片
  addPhoto: function () {
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        const tempFilePath = res.tempFiles[0].tempFilePath;
        this.addItemWithImage(tempFilePath, 'photo');
      }
    });
  },

  // 通用的添加图片元素方法
  addItemWithImage: function (imagePath, type) {
    wx.getImageInfo({
      src: imagePath,
      success: (imgInfo) => {
        // 计算画布中心位置
        const canvasCenter = this.data.canvasSize / 2;
        const originalWidth = imgInfo.width;
        const originalHeight = imgInfo.height;

        // 计算适合的大小，保持原始比例
        let itemWidth, itemHeight;
        const maxSize = this.data.canvasSize / 3; // 最大尺寸为画布的1/3

        if (originalWidth >= originalHeight) {
          itemWidth = maxSize;
          itemHeight = (originalHeight / originalWidth) * maxSize;
        } else {
          itemHeight = maxSize;
          itemWidth = (originalWidth / originalHeight) * maxSize;
        }

        // 创建一个新的可移动元素
        const newItem = {
          id: `${type}_${Date.now()}`,
          type: type,
          image: imagePath,
          originalWidth: originalWidth,
          originalHeight: originalHeight,
          aspectRatio: originalWidth / originalHeight,
          x: canvasCenter - (itemWidth / 2), // 居中放置
          y: canvasCenter - (itemHeight / 2), // 居中放置
          width: itemWidth,
          height: itemHeight,
          rotation: 0, // 初始旋转角度
          zIndex: this.data.selectedItems.length + 1 // 层级
        };

        // 添加到已选元素中
        const selectedItems = [...this.data.selectedItems, newItem];
        this.setData({ selectedItems });
      },
      fail: () => {
        wx.showToast({ title: `添加${type === 'photo' ? '照片' : '衣物'}失败`, icon: 'none' });
      }
    });
  },

  // 添加文字
  addText: function () {
    wx.showModal({
      title: '添加文字',
      editable: true,
      placeholderText: '请输入文字内容',
      success: (res) => {
        if (res.confirm && res.content) {
          // 计算画布中心位置
          const canvasCenter = this.data.canvasSize / 2;

          // 创建文字元素
          const newItem = {
            id: `text_${Date.now()}`,
            type: 'text',
            content: res.content,
            fontSize: 32, // 初始字体大小 rpx
            x: canvasCenter - 70, // 估算文字宽度的一半
            y: canvasCenter - 20, // 估算文字高度的一半
            width: 140, // 估算的文字宽度
            height: 40, // 估算的文字高度
            rotation: 0, // 初始旋转角度
            color: '#000000', // 初始颜色
            zIndex: this.data.selectedItems.length + 1 // 层级
          };

          // 添加到已选元素中
          const selectedItems = [...this.data.selectedItems, newItem];
          this.setData({ selectedItems });
        }
      }
    });
  },

  // 元素触摸开始事件
  itemTouchStart: function (e) {
    const itemId = e.currentTarget.dataset.id;
    this.touchStartX = e.touches[0].clientX;
    this.touchStartY = e.touches[0].clientY;

    // 标记当前选中的元素
    this.setData({ currentItemId: itemId });
    this.currentItemId = itemId;

    // 获取元素当前位置
    const item = this.data.selectedItems.find(item => item.id === itemId);
    if (item) {
      this.itemStartX = item.x;
      this.itemStartY = item.y;
    }
  },

  // 选择元素（点击事件）
  selectItem: function (e) {
    const itemId = e.currentTarget.dataset.id;
    this.setData({ currentItemId: itemId });
  },

  // 取消选择（点击空白区域）
  cancelSelection: function (e) {
    // 避免事件冒泡导致误触发
    if (e.target === e.currentTarget) {
      this.setData({ currentItemId: null });
    }
  },

  // 元素触摸移动事件
  itemTouchMove: function (e) {
    if (!this.currentItemId) return;

    const moveX = e.touches[0].clientX - this.touchStartX;
    const moveY = e.touches[0].clientY - this.touchStartY;

    // 更新元素位置
    const selectedItems = this.data.selectedItems.map(item => {
      if (item.id === this.currentItemId) {
        return {
          ...item,
          x: this.itemStartX + moveX,
          y: this.itemStartY + moveY
        };
      }
      return item;
    });

    this.setData({ selectedItems });
  },

  // 元素触摸结束事件
  itemTouchEnd: function () {
    this.currentItemId = null;
  },

  // 缩放开始
  scaleStart: function (e) {
    const itemId = e.currentTarget.dataset.id;
    this.touchStartX = e.touches[0].clientX;
    this.touchStartY = e.touches[0].clientY;

    // 设置当前操作为缩放
    this.currentOperation = 'scale';

    // 获取当前元素信息
    const item = this.data.selectedItems.find(item => item.id === itemId);
    if (item) {
      // 存储文本元素的初始字体大小
      if (item.type === 'text') {
        this.scaleStartFontSize = item.fontSize;
      }

      // 存储图片元素的初始尺寸
      this.scaleStartWidth = item.width;
      this.scaleStartHeight = item.height;
      this.itemAspectRatio = item.aspectRatio || (item.width / item.height);
    }
  },

  // 缩放移动
  scaleMove: function (e) {
    if (this.currentOperation !== 'scale' || !this.data.currentItemId) return;

    const moveX = e.touches[0].clientX - this.touchStartX;
    const moveY = e.touches[0].clientY - this.touchStartY;

    // 根据对角线移动距离计算缩放比例
    const distance = Math.sqrt(moveX * moveX + moveY * moveY);
    const direction = (moveX > 0 || moveY > 0) ? 1 : -1;
    const scaleFactor = 1 + (direction * distance / 200); // 调整缩放速度

    // 更新元素大小
    const selectedItems = this.data.selectedItems.map(item => {
      if (item.id === this.data.currentItemId) {
        // 文本元素处理
        if (item.type === 'text') {
          // 限制最小/最大字体大小
          const minFontSize = 12;
          const maxFontSize = 72;
          const newFontSize = Math.min(maxFontSize, Math.max(minFontSize, this.scaleStartFontSize * scaleFactor));

          // 同时按比例更新宽高
          const scaleRatio = newFontSize / this.scaleStartFontSize;
          const newWidth = this.scaleStartWidth * scaleRatio;
          const newHeight = this.scaleStartHeight * scaleRatio;

          return {
            ...item,
            fontSize: newFontSize,
            width: newWidth,
            height: newHeight
          };
        } else {
          // 图片和其他元素处理
          // 限制最小尺寸
          const minSize = 40;
          let newWidth, newHeight;

          // 保持原始宽高比
          if (item.aspectRatio) {
            if (item.aspectRatio >= 1) {
              // 宽大于高的图片
              newWidth = Math.max(minSize, this.scaleStartWidth * scaleFactor);
              newHeight = newWidth / item.aspectRatio;
            } else {
              // 高大于宽的图片
              newHeight = Math.max(minSize, this.scaleStartHeight * scaleFactor);
              newWidth = newHeight * item.aspectRatio;
            }
          } else {
            // 没有宽高比信息时的回退处理
            newWidth = Math.max(minSize, this.scaleStartWidth * scaleFactor);
            newHeight = Math.max(minSize, this.scaleStartHeight * scaleFactor);
          }

          return {
            ...item,
            width: newWidth,
            height: newHeight
          };
        }
      }
      return item;
    });

    this.setData({ selectedItems });
  },

  // 缩放结束
  scaleEnd: function () {
    this.currentOperation = null;
  },

  // 设置旋转参数
  setRotationParams: function (e, itemId) {
    // 获取元素信息
    const item = this.data.selectedItems.find(item => item.id === itemId);
    if (!item) return false;

    // 计算中心点
    if (item.type === 'text') {
      const query = wx.createSelectorQuery();
      query.select(`.canvas-item[data-id="${itemId}"]`).boundingClientRect();
      query.exec(rect => {
        if (rect && rect[0]) {
          this.itemCenterX = item.x + (rect[0].width / 2);
          this.itemCenterY = item.y + (rect[0].height / 2);
          this.initRotation(e, item);
        }
      });
    } else {
      this.itemCenterX = item.x + (item.width / 2);
      this.itemCenterY = item.y + (item.height / 2);
      this.initRotation(e, item);
    }
    return true;
  },

  // 初始化旋转角度
  initRotation: function (e, item) {
    const touchX = e.touches[0].clientX;
    const touchY = e.touches[0].clientY;
    this.startAngle = Math.atan2(touchY - this.itemCenterY, touchX - this.itemCenterX) * 180 / Math.PI;
    this.startRotation = item.rotation || 0;
  },

  // 旋转开始
  rotateStart: function (e) {
    const itemId = e.currentTarget.dataset.id;
    this.currentOperation = 'rotate';
    this.setRotationParams(e, itemId);
  },

  // 旋转移动
  rotateMove: function (e) {
    if (this.currentOperation !== 'rotate' || !this.data.currentItemId) return;

    // 计算当前触摸点与中心点形成的角度
    const touchX = e.touches[0].clientX;
    const touchY = e.touches[0].clientY;
    const currentAngle = Math.atan2(touchY - this.itemCenterY, touchX - this.itemCenterX) * 180 / Math.PI;

    // 计算角度差
    let rotationDiff = currentAngle - this.startAngle;

    // 更新元素旋转角度
    const selectedItems = this.data.selectedItems.map(item => {
      if (item.id === this.data.currentItemId) {
        return {
          ...item,
          rotation: (this.startRotation + rotationDiff) % 360
        };
      }
      return item;
    });

    this.setData({ selectedItems });
  },

  // 旋转结束
  rotateEnd: function () {
    this.currentOperation = null;
  },

  // 删除元素
  deleteItem: function (e) {
    const itemId = e.currentTarget.dataset.id;

    // 从选中列表中移除该元素
    const selectedItems = this.data.selectedItems.filter(item => item.id !== itemId);
    this.setData({
      selectedItems,
      currentItemId: null // 移除后取消选中状态
    });
  },

  // 显示元素上下文菜单
  showItemContextMenu: function (e) {
    const itemId = e.currentTarget.dataset.id;
    const item = this.data.selectedItems.find(item => item.id === itemId);

    if (!item) return;

    // 设置当前选中的元素
    this.setData({ currentItemId: itemId });

    // 根据元素类型显示不同的菜单选项
    const itemOptions = ['删除', '置于顶层', '置于底层'];

    // 如果是文本元素，添加"更改文本"和"更改颜色"选项
    if (item.type === 'text') {
      itemOptions.push('更改文本', '更改颜色');
    }

    wx.showActionSheet({
      itemList: itemOptions,
      success: (res) => {
        switch (res.tapIndex) {
          case 0: // 删除
            this.deleteItem({ currentTarget: { dataset: { id: itemId } } });
            break;
          case 1: // 置于顶层
            this.moveItemToTop(itemId);
            break;
          case 2: // 置于底层
            this.moveItemToBottom(itemId);
            break;
          case 3: // 更改文本
            if (item.type === 'text') {
              this.editTextContent(itemId, item.content);
            }
            break;
          case 4: // 更改颜色
            if (item.type === 'text') {
              this.editTextColor(itemId);
            }
            break;
        }
      }
    });
  },

  // 编辑文本内容
  editTextContent: function (itemId, currentContent) {
    wx.showModal({
      title: '编辑文本',
      editable: true,
      content: currentContent,
      success: (res) => {
        if (res.confirm && res.content) {
          // 更新文本内容
          const selectedItems = this.data.selectedItems.map(item => {
            if (item.id === itemId) {
              return {
                ...item,
                content: res.content
              };
            }
            return item;
          });

          this.setData({ selectedItems });
        }
      }
    });
  },

  // 编辑文本颜色
  editTextColor: function (itemId) {
    const colors = [
      { name: '黑色', value: '#000000' },
      { name: '白色', value: '#ffffff' },
      { name: '红色', value: '#ff0000' },
      { name: '蓝色', value: '#0000ff' },
      { name: '绿色', value: '#00ff00' },
      { name: '黄色', value: '#ffff00' }
    ];

    const colorNames = colors.map(color => color.name);

    wx.showActionSheet({
      itemList: colorNames,
      success: (res) => {
        const selectedColor = colors[res.tapIndex].value;

        // 更新文本颜色
        const selectedItems = this.data.selectedItems.map(item => {
          if (item.id === itemId) {
            return {
              ...item,
              color: selectedColor
            };
          }
          return item;
        });

        this.setData({ selectedItems });
      }
    });
  },

  // 将元素移到顶层
  moveItemToTop: function (itemId) {
    // 找出当前最大zIndex
    let maxZIndex = 0;
    this.data.selectedItems.forEach(item => {
      if (item.zIndex > maxZIndex) {
        maxZIndex = item.zIndex;
      }
    });

    // 更新目标元素的zIndex
    const selectedItems = this.data.selectedItems.map(item => {
      if (item.id === itemId) {
        return { ...item, zIndex: maxZIndex + 1 };
      }
      return item;
    });

    this.setData({ selectedItems });
    wx.showToast({ title: '已置于顶层', icon: 'success' });
  },

  // 将元素移到底层
  moveItemToBottom: function (itemId) {
    // 找出当前最小zIndex
    let minZIndex = 999999;
    this.data.selectedItems.forEach(item => {
      if (item.zIndex < minZIndex) {
        minZIndex = item.zIndex;
      }
    });

    // 更新目标元素的zIndex
    const selectedItems = this.data.selectedItems.map(item => {
      if (item.id === itemId) {
        return { ...item, zIndex: minZIndex - 1 };
      }
      return item;
    });

    this.setData({ selectedItems });
    wx.showToast({ title: '已置于底层', icon: 'success' });
  },

  // 完成拼图
  finishCollage: function () {
    // 清除选中状态
    this.setData({ currentItemId: null });

    wx.showLoading({ title: '生成中...' });

    this.generateCollage()
      .then(tempFilePath => {
        wx.hideLoading();

        let url = '../save_collage/save_collage?collageImage=' + encodeURIComponent(tempFilePath);

        if (this.data.categoryId) {
          url += '&categoryId=' + this.data.categoryId;
        }

        wx.navigateTo({ url: url });
      })
      .catch(error => {
        wx.hideLoading();
        wx.showToast({ title: '生成失败，请重试', icon: 'none' });
      });
  },

  // 拼图生成方法 - 返回Promise
  generateCollage: function () {
    return new Promise((resolve, reject) => {
      // 获取 canvas 上下文，传入当前页面实例
      const ctx = wx.createCanvasContext('hiddenCanvas', this);

      const canvasSize = this.data.canvasSize;      // 原始画布尺寸（如设计稿尺寸）
      const hiddenCanvasSize = 1000;                  // 隐藏画布尺寸，必须与页面中 canvas 的宽高一致
      const scaleFactor = hiddenCanvasSize / canvasSize;

      // 绘制背景色
      ctx.setFillStyle(this.data.canvasBackgroundColor);
      ctx.fillRect(0, 0, hiddenCanvasSize, hiddenCanvasSize);

      // 将选中元素按 zIndex 升序排序
      const sortedItems = [...this.data.selectedItems].sort((a, b) => a.zIndex - b.zIndex);

      // 把每个绘制操作封装成 Promise
      const drawPromises = sortedItems.map(item => {
        return new Promise((resolveItem) => {
          const x = item.x * scaleFactor;
          const y = item.y * scaleFactor;
          ctx.save();

          if (item.type === 'text') {
            // 绘制文字
            const fontSize = (item.fontSize || 20) * scaleFactor;
            ctx.setFontSize(fontSize);
            ctx.setTextAlign('center');
            ctx.setTextBaseline('middle');

            const centerX = x + (item.width * scaleFactor / 2);
            const centerY = y + (item.height * scaleFactor / 2);
            ctx.translate(centerX, centerY);

            if (item.rotation) {
              ctx.rotate(item.rotation * Math.PI / 180);
            }
            ctx.setFillStyle(item.color || '#000000');
            ctx.fillText(item.content, 0, 0);
            ctx.restore();
            resolveItem();
          } else {
            // 绘制图片
            const width = item.width * scaleFactor;
            const height = item.height * scaleFactor;

            // 定义一个绘制图片的内部函数
            const drawImageFunction = (localPath) => {
              ctx.translate(x + width / 2, y + height / 2);
              if (item.rotation) {
                ctx.rotate(item.rotation * Math.PI / 180);
              }
              ctx.drawImage(localPath, -width / 2, -height / 2, width, height);
              ctx.restore();
              resolveItem();
            };

            // 判断图片是否为云文件
            if (item.image && item.image.indexOf('cloud://') === 0) {
              wx.cloud.downloadFile({
                fileID: item.image,
                success: res => {
                  drawImageFunction(res.tempFilePath);
                },
                fail: err => {
                  console.error('下载云文件失败：', err);
                  // 若下载失败，可以跳过当前图片（或使用占位图）
                  ctx.restore();
                  resolveItem();
                }
              });
            } else {
              // 非云文件直接绘制
              drawImageFunction(item.image);
            }
          }
        });
      });

      // 等待所有绘制操作完成
      Promise.all(drawPromises)
        .then(() => {
          // 调用 draw 确保所有绘制命令发送到渲染层
          ctx.draw(false, () => {
            // 延时500ms确保所有绘制内容真正渲染到 canvas 上
            setTimeout(() => {
              wx.canvasToTempFilePath({
                canvasId: 'hiddenCanvas',
                x: 0,
                y: 0,
                width: hiddenCanvasSize,
                height: hiddenCanvasSize,
                destWidth: hiddenCanvasSize * 2,
                destHeight: hiddenCanvasSize * 2,
                fileType: 'png',
                quality: 1,
                success: res => {
                  resolve(res.tempFilePath);
                },
                fail: err => {
                  console.error('生成图片失败：', err);
                  reject(err);
                }
              }, this);
            }, 500); // 延时可以根据实际情况调整
          });
        })
        .catch(err => {
          reject(err);
        });
    });
  }
}) 