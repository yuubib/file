// pages/wardrobe/wardrobe.js
/**
 * 我的衣橱（主页）
 * 2025‑04‑14 重构：结构化、函数小而专、命名语义化
 */
const app = getApp();
const db = app.globalData.db;

Page({
  /* ----------------------------- data ----------------------------- */
  data: {
    title: '我的衣橱',
    clothesCategories: [], // [{ _id,name,count,items:[{_id,name,image}] }]
    showDropdown: false, // 切换衣橱弹层
    isGridView: true, // true=网格 false=列表
    showMoreMenu: false, // 右上角“...”
  },

  /* -------------------------- 生命周期 --------------------------- */
  onLoad() {
    // 读取上次视图模式
    const mode = wx.getStorageSync('wardrobe_view_mode');
    if (mode) this.setData({
      isGridView: mode === 'grid'
    });
    this.refresh();
  },
  onShow() {
    this.refresh();
  },

  /* ------------------------- 数据获取 --------------------------- */
  async refresh() {
    wx.showLoading({
      title: '加载中...'
    });
    try {
      const [catRes, itemRes] = await Promise.all([
        db.collection('categories').orderBy('order', 'asc').get(),
        db.collection('clothes').get(),
      ]);

      const categories = catRes.data.map(cat => {
        const items = itemRes.data.filter(it => it.categoryId === cat._id);
        return {
          ...cat,
          count: items.length,
          items: items.map(({
            _id,
            name,
            image
          }) => ({
            _id,
            name: name || '未命名',
            image
          })),
        };
      });
      this.setData({
        clothesCategories: categories
      });
    } catch (e) {
      console.error('refresh error', e);
      wx.showToast({
        title: '获取数据失败',
        icon: 'none'
      });
    } finally {
      wx.hideLoading();
    }
  },

  /* ------------------------- UI：弹层 --------------------------- */
  toggleDropdown() {
    this.setData({
      showDropdown: !this.data.showDropdown
    });
  },
  closeDropdown() {
    this.setData({
      showDropdown: false
    });
  },
  stopPropagation() {},

  /* -------------------- 单品：查看 / 编辑 / 新增 -------------------- */
  viewItemDetail({
    currentTarget
  }) {
    wx.navigateTo({
      url: `../item_detail/item_detail?id=${currentTarget.dataset.id}`
    });
  },
  onImageTap({
    currentTarget
  }) {
    wx.navigateTo({
      url: `../add/add?id=${currentTarget.dataset.id}`
    });
  },
  addClothItem({
    currentTarget
  }) {
    const categoryId = currentTarget.dataset.category;
    wx.showActionSheet({
      itemList: ['创建单品', '拍照', '从相册添加', '从相册批量添加'],
      success: ({
        tapIndex
      }) => {
        [
          () => this.goAdd({
            categoryId
          }),
          () => this.pickCamera(categoryId),
          () => this.pickAlbum(categoryId, false),
          () => this.pickAlbum(categoryId, true),
        ][tapIndex]?.();
      },
    });
  },

  /* -------------------- 图片选择封装 -------------------- */
  async pickCamera(categoryId) {
    const [path] = await this.chooseMedia({
      sourceType: ['camera'],
      count: 1
    });
    if (path) this.goAdd({
      categoryId,
      imagePath: path
    });
  },
  async pickAlbum(categoryId, multiple) {
    const paths = await this.chooseMedia({
      sourceType: ['album'],
      count: multiple ? 9 : 1
    });
    if (!paths) return;
    if (multiple && paths.length > 1) {
      app.globalData.tempImagePaths = paths;
      this.goAdd({
        categoryId,
        multiple: true
      });
    } else {
      this.goAdd({
        categoryId,
        imagePath: paths[0]
      });
    }
  },
  chooseMedia(opts) {
    return new Promise(resolve => {
      wx.chooseMedia({
        mediaType: ['image'],
        ...opts,
        success: r => resolve(r.tempFiles.map(f => f.tempFilePath)),
        fail: () => resolve(null),
      });
    });
  },
  goAdd({
    categoryId,
    imagePath,
    multiple
  }) {
    let url = `../add/add?categoryId=${categoryId}`;
    if (imagePath) url += `&imagePath=${encodeURIComponent(imagePath)}`;
    if (multiple) url += '&multiple=true';
    wx.navigateTo({
      url
    });
  },

  /* -------------------- 分类相关 -------------------- */
  async promptCreateCategory() {
    wx.showModal({
      title: '创建衣橱分类',
      editable: true,
      placeholderText: '请输入分类名称',
      success: async ({
        confirm,
        content
      }) => {
        if (!confirm || !content.trim()) return;
        wx.showLoading({
          title: '创建中...'
        });
        try {
          await this.addCategoryToCloud(content.trim());
          wx.showToast({
            title: '创建成功',
            icon: 'success'
          });
        } catch (e) {
          wx.showToast({
            title: '创建失败',
            icon: 'none'
          });
        } finally {
          wx.hideLoading();
        }
      },
    });
  },
  async addCategoryToCloud(name) {
    const {
      data: last
    } = await db.collection('categories').orderBy('order', 'desc').limit(1).get();
    await db.collection('categories').add({
      data: {
        name,
        count: 0,
        order: last[0]?.order + 1 || 0,
        createTime: new Date(),
        updateTime: new Date()
      },
    });
    this.refresh();
  },

  /* -------------------- 底部 + 按钮 -------------------- */
  onAddButtonTap() {
    wx.showActionSheet({
      itemList: ['创建分类', '创建单品', '拍照', '从相册添加', '从相册批量添加'],
      success: ({
        tapIndex
      }) => {
        [
          () => this.promptCreateCategory(),
          () => this.chooseCategoryThenAdd(),
          () => this.pickAfterCategory({
            sourceType: ['camera']
          }),
          () => this.pickAfterCategory({
            sourceType: ['album'],
            multiple: false
          }),
          () => this.pickAfterCategory({
            sourceType: ['album'],
            multiple: true
          }),
        ][tapIndex]?.();
      },
    });
  },
  chooseCategoryThenAdd() {
    const names = this.data.clothesCategories.map(c => c.name);
    if (!names.length) return wx.showToast({
      title: '请先创建分类',
      icon: 'none'
    });
    wx.showActionSheet({
      itemList: names,
      success: ({
        tapIndex
      }) => this.goAdd({
        categoryId: this.data.clothesCategories[tapIndex]._id
      }),
    });
  },
  async pickAfterCategory({
    sourceType,
    multiple
  }) {
    const paths = await this.chooseMedia({
      sourceType,
      count: multiple ? 9 : 1
    });
    if (!paths) return;
    const names = this.data.clothesCategories.map(c => c.name);
    if (!names.length) return wx.showToast({
      title: '请先创建分类',
      icon: 'none'
    });
    wx.showActionSheet({
      itemList: names,
      success: ({
        tapIndex
      }) => {
        const categoryId = this.data.clothesCategories[tapIndex]._id;
        if (multiple && paths.length > 1) {
          app.globalData.tempImagePaths = paths;
          this.goAdd({
            categoryId,
            multiple: true
          });
        } else {
          this.goAdd({
            categoryId,
            imagePath: paths[0]
          });
        }
      },
    });
  },

  /* -------------------- 顶部 ... 菜单 -------------------- */
  toggleMoreMenu() {
    this.setData({
      showMoreMenu: !this.data.showMoreMenu
    });
  },
  closeMoreMenu() {
    this.setData({
      showMoreMenu: false
    });
  },
  switchViewStyle() {
    const isGrid = !this.data.isGridView;
    this.setData({
      isGridView: isGrid
    });
    wx.setStorageSync('wardrobe_view_mode', isGrid ? 'grid' : 'list');
    this.closeMoreMenu();
  },
  showDisplaySettings() {
    this.tipDev('显示设置');
    this.closeMoreMenu();
  },

  /* -------------------- 其它导航 -------------------- */
  switchToTiledView() {
    wx.navigateTo({
      url: '../items/items'
    });
  },
  toggleGridView() {
    wx.navigateTo({
      url: '../category_management/category_management'
    });
  },
  goToRandomOutfitGenerator() {
    wx.navigateTo({
      url: '../random_rules/random_rules'
    });
    this.closeMoreMenu();
  },

  /* -------------------- util -------------------- */
  tipDev(name) {
    wx.showToast({
      title: `${name}功能开发中`,
      icon: 'none'
    });
  },
});