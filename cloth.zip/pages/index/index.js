// pages/outfit_home/outfit_home.js
/**
 * 我的搭配（首页）
 * 2025‑04‑14  重构：代码规范、性能优化、Bug 修复
 */
const app = getApp();
const db = app.globalData.db;

Page({
  /* ----------------------------- data ----------------------------- */
  data: {
    title: '我的搭配',

    // UI 状态
    showDropdown: false,
    showMoreMenu: false,
    isGridView: true,

    // 分类 & 展示
    categories: [], // [{ _id,name,count,items:[{id,image,type}] }]
  },

  /* -------------------------- 生命周期 --------------------------- */
  async onLoad() {
    await this.ensureDefaultCategories();
    await this.refreshCategories();
  },
  onShow() {
    this.loadOutfitData();
  },

  /* ------------------------- 初始化 --------------------------- */
  /** 首次进入时云端无数据 → 写入默认分类 */
  async ensureDefaultCategories() {
    try {
      const {
        total
      } = await db.collection('outfit_categories').count();
      if (total) return;

      const defaults = ['工作', '休闲', '派对', '正式', '度假'].map((name, i) => ({
        name,
        count: 0,
        order: i + 1,
        createTime: new Date(),
        updateTime: new Date(),
      }));
      await Promise.all(defaults.map(c => db.collection('outfit_categories').add({
        data: c
      })));
    } catch (e) {
      console.error('ensureDefaultCategories', e);
    }
  },

  /* ------------------------- 分类加载 --------------------------- */
  async refreshCategories() {
    wx.showLoading({
      title: '加载中...'
    });
    try {
      const {
        data
      } = await db.collection('outfit_categories').orderBy('order', 'asc').get();
      this.setData({
        categories: data
      });
    } catch (e) {
      wx.showToast({
        title: '加载分类失败',
        icon: 'none'
      });
      console.error('refreshCategories', e);
    } finally {
      wx.hideLoading();
    }
  },

  /* ------------------------- 搭配 & 拼贴计数 --------------------------- */
  async loadOutfitData() {
    try {
      const localOutfits = wx.getStorageSync('outfits') || [];
      const {
        data: collages = []
      } = await db.collection('collages').get();

      // map for quick lookup
      const outfitCountMap = {};
      localOutfits.forEach(o => {
        outfitCountMap[o.categoryId] = (outfitCountMap[o.categoryId] || 0) + 1;
      });

      const collageMap = {};
      collages.forEach(c => {
        collageMap[c.categoryId] = collageMap[c.categoryId] || [];
        collageMap[c.categoryId].push(c);
      });

      const cats = this.data.categories.map(cat => {
        const outfits = outfitCountMap[cat._id] || 0;
        const collageList = collageMap[cat._id] || [];
        const count = outfits + collageList.length;

        // 最近 3 张拼贴图
        const items = collageList
          .sort((a, b) => new Date(b.createTime || b.createdAt || 0) - new Date(a.createTime || a.createdAt || 0))
          .slice(0, 3)
          .map(i => ({
            id: i._id,
            image: i.image,
            type: 'collage'
          }));

        // 若计数变化，更新云端
        if (cat.count !== count) this.updateCategoryCount(cat._id, count);

        return {
          ...cat,
          count,
          items
        };
      });

      this.setData({
        categories: cats
      });
    } catch (e) {
      console.error('loadOutfitData', e);
    }
  },

  async updateCategoryCount(id, count) {
    try {
      await db.collection('outfit_categories').doc(id).update({
        data: {
          count,
          updateTime: new Date()
        },
      });
    } catch (e) {
      console.error('updateCategoryCount', id, e);
    }
  },

  /* ------------------------- UI 操作 --------------------------- */
  toggleDropdown() {
    this.setData({
      showDropdown: !this.data.showDropdown
    });
  },
  closeWardrobePopup() {
    this.setData({
      showDropdown: false
    });
  },
  stopPropagation() {},

  toggleMoreMenu() {
    this.setData({
      showMoreMenu: !this.data.showMoreMenu
    });
  },
  closeMoreMenu() {
    this.setData({
      showMoreMenu: false
    });
  },

  switchViewStyle() {
    const isGrid = !this.data.isGridView;
    this.setData({
      isGridView: isGrid
    });
    wx.setStorageSync('outfit_view_mode', isGrid ? 'grid' : 'list');
    wx.showToast({
      title: `已切换为${isGrid ? '网格' : '列表'}视图`,
      icon: 'none'
    });
    this.closeMoreMenu();
  },

  showDisplaySettings() {
    this.tipDev('显示设置');
    this.closeMoreMenu();
  },

  /* ------------------------- 添加 / 创建 --------------------------- */
  onAddButtonTap() {
    wx.showActionSheet({
      itemList: ['创建搭配', '创建分类', '拼图', '随机', '照片标注', '从相册批量添加'],
      success: ({
        tapIndex
      }) => this.handleAddAction(tapIndex),
    });
  },
  addOutfitItem({
    currentTarget
  }) {
    wx.showActionSheet({
      itemList: ['创建搭配', '创建分类', '拼图', '随机', '照片标注', '从相册批量添加'],
      success: ({
        tapIndex
      }) => this.handleAddAction(tapIndex, currentTarget.dataset.id),
    });
  },

  handleAddAction(index, categoryId) {
    const actions = [
      () => {}, // 创建搭配（待实现）
      () => this.createCategory(),
      () => this.createCollage(categoryId),
      () => this.createRandomOutfit(),
      () => this.tipDev('照片标注'),
      () => this.batchAddFromAlbum(),
    ];
    actions[index]?.();
  },

  createCategory() {
    wx.showModal({
      title: '创建分类',
      editable: true,
      placeholderText: '请输入分类名称',
      success: async ({
        confirm,
        content
      }) => {
        if (!confirm || !content.trim()) return;
        wx.showLoading({
          title: '创建中...'
        });
        try {
          await this.addOutfitCategoryToCloud(content.trim());
          wx.showToast({
            title: '创建成功',
            icon: 'success'
          });
        } catch {
          wx.showToast({
            title: '创建失败',
            icon: 'none'
          });
        }
        wx.hideLoading();
      },
    });
  },
  async addOutfitCategoryToCloud(name) {
    const {
      data: last
    } = await db.collection('outfit_categories').orderBy('order', 'desc').limit(1).get();
    await db.collection('outfit_categories').add({
      data: {
        name,
        count: 0,
        order: (last[0]?.order || 0) + 1,
        createTime: new Date(),
        updateTime: new Date()
      },
    });
    this.refreshCategories();
  },

  createCollage(categoryId) {
    wx.navigateTo({
      url: `../collage/collage${categoryId ? '?categoryId=' + categoryId : ''}`
    });
  },
  createRandomOutfit() {
    wx.navigateTo({
      url: '../random_rules/random_rules'
    });
  },
  batchAddFromAlbum() {
    wx.chooseMedia({
      count: 9,
      mediaType: ['image'],
      sourceType: ['album'],
      success: () => this.tipDev('批量添加'),
    });
  },

  /* ------------------------- 分类管理 & 查看 --------------------------- */
  toggleGridView() {
    wx.navigateTo({
      url: '../category_management/category_management?type=outfit'
    });
  },
  switchToTiledView() {
    wx.navigateTo({
      url: '../outfits/outfits'
    });
  },
  showCategorySettings({
    currentTarget
  }) {
    const {
      id
    } = currentTarget.dataset;
    const cat = this.data.categories.find(c => c._id === id);
    wx.navigateTo({
      url: `../outfits/outfits?categoryId=${id}&categoryName=${cat?.name || ''}`
    });
  },

  viewOutfitDetail({
    currentTarget
  }) {
    wx.navigateTo({
      url: `../collage_detail/collage_detail?id=${currentTarget.dataset.id}`
    });
  },
  onCollageTap({
    currentTarget
  }) {
    wx.navigateTo({
      url: `/pages/save_collage/save_collage?id=${currentTarget.dataset.id}`
    });
  },

  /* ------------------------- util --------------------------- */
  tipDev(name) {
    wx.showToast({
      title: `${name}功能开发中`,
      icon: 'none'
    });
  },
});