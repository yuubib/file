Page({
  data: {
    outfits: [],
    totalCount: 0,
    sortOptions: ['最近添加', '最早添加', '场合', '季节'],
    currentSort: '最近添加',
    showSortDropdown: false,
    viewMode: 'grid', // grid or list
    filterApplied: false
  },
  
  // ===== 生命周期函数 =====
  
  onLoad: function(options) {
    // 保存所有的分类ID
    this.categoryId = options.categoryId || null;
    this.categoryName = options.categoryName || '全部搭配';
    
    // 设置页面标题
    wx.setNavigationBarTitle({
      title: this.categoryName
    });
    
    // 加载搭配
    this.loadOutfits();
  },
  
  onShow: function() {
    // 每次显示页面时重新加载数据，确保数据最新
    this.loadOutfits();
  },
  
  // ===== 数据加载功能 =====
  
  // 综合加载数据方法
  loadOutfits: function() {
    if (this.categoryId) {
      // 按分类加载
      this.loadOutfitsByCategory(this.categoryId);
    } else {
      // 加载全部
      this.loadAllOutfits();
    }
  },
  
  // 加载所有搭配
  loadAllOutfits: async function() {
    wx.showLoading({
      title: '加载中...'
    });
    
    try {
      // 从云数据库加载拼图数据
      const db = wx.cloud.database();
      const { data: collages } = await db.collection('collages').get();
      
      // 从本地存储加载搭配数据（如果需要）
      const localOutfits = wx.getStorageSync('outfits') || [];
      
      // 合并数据
      const allOutfits = [
        ...collages.map(item => ({
          ...item,
          type: 'collage'
        })),
        ...localOutfits.map(item => ({
          ...item,
          type: 'outfit'
        }))
      ];
      
      this.setData({
        outfits: allOutfits,
        totalCount: allOutfits.length
      });
      
      // 应用当前排序
      this.sortOutfits(this.data.currentSort);
      
      wx.hideLoading();
    } catch (error) {
      wx.hideLoading();
      wx.showToast({
        title: '加载失败',
        icon: 'none'
      });
    }
  },
  
  // 按分类加载搭配
  loadOutfitsByCategory: async function(categoryId) {
    wx.showLoading({
      title: '加载中...'
    });
    
    try {
      // 从云数据库加载该分类的拼图数据
      const db = wx.cloud.database();
      const { data: collages } = await db.collection('collages')
        .where({
          categoryId: categoryId
        })
        .get();
      
      // 从本地存储加载该分类的搭配数据（如果需要）
      const localOutfits = wx.getStorageSync('outfits') || [];
      const filteredLocalOutfits = localOutfits.filter(item => item.categoryId === categoryId);
      
      // 合并数据
      const categoryOutfits = [
        ...collages.map(item => ({
          ...item,
          type: 'collage'
        })),
        ...filteredLocalOutfits.map(item => ({
          ...item,
          type: 'outfit'
        }))
      ];
      
      this.setData({
        outfits: categoryOutfits,
        totalCount: categoryOutfits.length
      });
      
      // 应用当前排序
      this.sortOutfits(this.data.currentSort);
      
      wx.hideLoading();
    } catch (error) {
      wx.hideLoading();
      wx.showToast({
        title: '加载失败',
        icon: 'none'
      });
    }
  },
  
  // ===== 排序与筛选功能 =====
  
  // 切换排序下拉菜单
  toggleSortDropdown: function() {
    this.setData({
      showSortDropdown: !this.data.showSortDropdown
    });
  },
  
  // 选择排序选项
  selectSortOption: function(e) {
    const option = e.currentTarget.dataset.option;
    this.setData({
      currentSort: option,
      showSortDropdown: false
    });
    
    // 根据选项进行排序
    this.sortOutfits(option);
  },
  
  // 对搭配列表进行排序
  sortOutfits: function(sortBy) {
    let sortedOutfits = [...this.data.outfits];
    
    switch(sortBy) {
      case '最近添加':
        sortedOutfits.sort((a, b) => {
          // 使用createdAt字段，如果存在的话
          const dateA = a.createdAt ? new Date(a.createdAt) : (a.createTime ? new Date(a.createTime) : 0);
          const dateB = b.createdAt ? new Date(b.createdAt) : (b.createTime ? new Date(b.createTime) : 0);
          return dateB - dateA;
        });
        break;
      case '最早添加':
        sortedOutfits.sort((a, b) => {
          // 使用createdAt字段，如果存在的话
          const dateA = a.createdAt ? new Date(a.createdAt) : (a.createTime ? new Date(a.createTime) : 0);
          const dateB = b.createdAt ? new Date(b.createdAt) : (b.createTime ? new Date(b.createTime) : 0);
          return dateA - dateB;
        });
        break;
      case '场合':
        sortedOutfits.sort((a, b) => {
          const occasionA = a.categoryName || '';
          const occasionB = b.categoryName || '';
          return occasionA.localeCompare(occasionB, 'zh');
        });
        break;
      case '季节':
        sortedOutfits.sort((a, b) => {
          const seasonA = a.season || '';
          const seasonB = b.season || '';
          return seasonA.localeCompare(seasonB, 'zh');
        });
        break;
    }
    
    this.setData({
      outfits: sortedOutfits
    });
  },
  
  // ===== 视图与操作功能 =====
  
  // 切换视图模式（网格/列表）
  toggleViewMode: function() {
    this.setData({
      viewMode: this.data.viewMode === 'grid' ? 'list' : 'grid'
    });
  },
  
  // 显示筛选选项
  showFilterOptions: function() {
    // 显示筛选选项
    wx.showActionSheet({
      itemList: ['按场合筛选', '按季节筛选', '按标签筛选', '重置筛选'],
      success: (res) => {
        // 根据选择执行不同的筛选操作
      }
    });
  },
  
  // ===== 添加与创建功能 =====
  
  // 添加新搭配，显示添加选项菜单
  addNewOutfit: function() {
    // 显示添加选项菜单
    wx.showActionSheet({
      itemList: ['创建搭配', '创建分类', '拼图', '随机', '照片标注', '从相册批量添加'],
      success: (res) => {
        const index = res.tapIndex;
        // 根据选择的选项执行不同操作
        switch(index) {
          case 0: // 创建搭配 - 不执行任何操作，使其无响应
            break;
          case 1: // 创建分类
            this.createCategory();
            break;
          case 2: // 拼图
            this.createCollage();
            break;
          case 3: // 随机
            this.createRandomOutfit();
            break;
          case 4: // 照片标注
            this.photoTag();
            break;
          case 5: // 从相册批量添加
            this.batchAddFromAlbum();
            break;
        }
      }
    });
  },
  
  // 创建分类
  createCategory: function() {
    wx.showModal({
      title: '创建分类',
      editable: true,
      placeholderText: '请输入分类名称',
      content: '',
      success: async (res) => {
        if (res.confirm && res.content.trim()) {
          wx.showLoading({
            title: '创建中...'
          });
          
          try {
            // 创建新的分类
            const db = wx.cloud.database();
            
            // 获取当前最大的order
            const { data: categories } = await db.collection('outfit_categories')
              .orderBy('order', 'desc')
              .limit(1)
              .get();
            
            const maxOrder = categories.length > 0 ? categories[0].order : 0;
            
            // 创建新分类
            await db.collection('outfit_categories').add({
              data: {
                name: res.content.trim(),
                count: 0,
                order: maxOrder + 1,
                createTime: new Date(),
                updateTime: new Date()
              }
            });
            
            wx.hideLoading();
            wx.showToast({
              title: '创建成功',
              icon: 'success'
            });
          } catch (error) {
            wx.hideLoading();
            wx.showToast({
              title: '创建失败',
              icon: 'none'
            });
          }
        }
      }
    });
  },
  
  // 显示拼图功能开发中提示
  createCollage: function() {
    this.showDevelopingFeature('拼图');
  },
  
  // 显示随机搭配功能开发中提示
  createRandomOutfit: function() {
    this.showDevelopingFeature('随机搭配');
  },
  
  // 显示照片标注功能开发中提示
  photoTag: function() {
    this.showDevelopingFeature('照片标注');
  },
  
  // 显示批量添加功能开发中提示
  batchAddFromAlbum: function() {
    this.showDevelopingFeature('批量添加');
  },
  
  // 查看搭配详情
  viewOutfitDetail: function(e) {
    const outfitId = e.currentTarget.dataset.id;
    const outfitType = e.currentTarget.dataset.type;
    
    // 根据类型跳转到不同的详情页面
    if (outfitType === 'collage') {
      wx.navigateTo({
        url: `../collage_detail/collage_detail?id=${outfitId}`
      });
    } else {
      wx.navigateTo({
        url: `../outfit_detail/outfit_detail?id=${outfitId}`
      });
    }
  },
  
  // 统一显示开发中的功能提示
  showDevelopingFeature: function(featureName) {
    wx.showToast({
      title: `${featureName}功能开发中`,
      icon: 'none'
    });
  }
}); 