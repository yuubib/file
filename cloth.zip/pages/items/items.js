// pages/choose_items/choose_items.js
/**
 * 选择衣物（多选）
 * 2025‑04‑14  重构：性能优化 / 代码规范
 */
const app = getApp();
const db = app.globalData.db;

Page({
  /* ----------------------------- data ----------------------------- */
  data: {
    // 源数据
    items: [], // 所有衣物
    categories: [], // 一级分类
    subcategories: [], // 二级分类

    // 过滤状态
    selectedCategory: '全部',
    selectedSubcategory: '',

    // 派生数据
    filteredSubcategories: [],
    filteredItems: [],

    // 选择状态
    selectedItems: [],
    selectionCount: 0,
  },

  /* -------------------------- 生命周期 --------------------------- */
  async onLoad() {
    await this.initData();
  },

  /* ------------------------- 数据加载 --------------------------- */
  /** 一次并行加载分类 / 子分类 / 衣物 */
  async initData() {
    wx.showLoading({
      title: '加载中...'
    });
    try {
      const [catRes, subRes, itemRes] = await Promise.all([
        db.collection('categories').orderBy('order', 'asc').get(),
        db.collection('subcategories').orderBy('order', 'asc').get(),
        db.collection('clothes').get(),
      ]);

      this.setData({
        categories: catRes.data,
        subcategories: subRes.data,
        items: itemRes.data,
        filteredItems: itemRes.data,
        filteredSubcategories: subRes.data, // 默认全部
      });
    } catch (e) {
      console.error('initData error', e);
      wx.showToast({
        title: '加载失败，使用本地缓存',
        icon: 'none'
      });
      const local = wx.getStorageSync('clothItems') || [];
      this.setData({
        items: local,
        filteredItems: local
      });
    } finally {
      wx.hideLoading();
    }
  },

  /* ------------------------- 分类筛选 --------------------------- */
  selectCategory({
    currentTarget
  }) {
    const selectedCategory = currentTarget.dataset.category;
    this.setData({
      selectedCategory,
      selectedSubcategory: ''
    }, () => {
      this.updateFilteredSubcategories();
      this.applyFilters();
    });
  },

  selectSubcategory({
    currentTarget
  }) {
    this.setData({
      selectedSubcategory: currentTarget.dataset.subcategory
    }, this.applyFilters);
  },

  /** 根据一级分类刷新二级分类列表 */
  updateFilteredSubcategories() {
    const {
      selectedCategory,
      categories,
      subcategories
    } = this.data;
    if (selectedCategory === '全部') {
      this.setData({
        filteredSubcategories: subcategories
      });
      return;
    }
    const cat = categories.find(c => c.name === selectedCategory);
    const list = cat ? subcategories.filter(s => s.parentId === cat._id) : [];
    this.setData({
      filteredSubcategories: list
    });
  },

  /** 应用筛选 */
  applyFilters() {
    const {
      items,
      selectedCategory,
      selectedSubcategory,
      categories
    } = this.data;
    let res = [...items];

    if (selectedCategory !== '全部') {
      const cat = categories.find(c => c.name === selectedCategory);
      if (cat) res = res.filter(i => i.categoryId === cat._id);
    }
    if (selectedSubcategory) res = res.filter(i => i.subcategoryId === selectedSubcategory);

    this.setData({
      filteredItems: res
    });
  },

  /* ------------------------- 选择逻辑 --------------------------- */
  toggleSelectItem({
    currentTarget
  }) {
    const id = currentTarget.dataset.id;
    const idx = this.data.selectedItems.findIndex(it => it._id === id);
    let list;
    if (idx === -1) {
      const item = this.data.items.find(it => it._id === id);
      if (!item) return;
      list = [...this.data.selectedItems, item];
    } else {
      list = [...this.data.selectedItems];
      list.splice(idx, 1);
    }
    this.setData({
      selectedItems: list,
      selectionCount: list.length
    });
  },

  /* ------------------------- 操作 --------------------------- */
  complete() {
    if (!this.data.selectionCount)
      return wx.showToast({
        title: '请至少选择一个单品',
        icon: 'none'
      });

    const pages = getCurrentPages();
    const prev = pages[pages.length - 2];
    if (prev?.addSelectedClothingItems) prev.addSelectedClothingItems(this.data.selectedItems);
    wx.navigateBack();
  },
  cancel() {
    wx.navigateBack();
  },
});