// app.js
App({
  onLaunch: function () {
    // 展示本地存储能力
    const logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 初始化云开发
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力')
    } else {
      wx.cloud.init({
        env: 'cloud1-7g4mn88sf5a1e031',
        traceUser: true,
      })
      // 获取数据库实例
      this.globalData.db = wx.cloud.database()
    }

    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
        console.log('登录成功：', res)
      }
    })
    this.checkAndInitDefaultData()
    .then(() => {
      console.log('默认数据检查 & 初始化完成')
    })
    .catch(err => {
      console.error('初始化数据时发生错误', err)
    })
  },
  globalData: {
    userInfo: null,
    db: null,
    tempImagePaths: []
  },

  checkAndInitDefaultData: async function() {
    const db = this.globalData.db
    if (!db) return

    try {
      // 例如，检查 "categories" 集合是否已存在数据
      const res = await db.collection('categories').count()
      if (res.total === 0) {
        // 如果数据库中还没有任何分类数据，就插入几条“默认分类”
        const defaultCategories = [
          { name: '上装', order: 1, createTime: new Date() },
          { name: '下装', order: 2, createTime: new Date() },
          { name: '鞋子', order: 3, createTime: new Date() },
          // ...根据需要添加更多
        ]

        // 批量插入
        const tasks = defaultCategories.map(cat => {
          return db.collection('categories').add({ data: cat })
        })
        await Promise.all(tasks)

        // 同理，你可以再检查别的集合，比如 "clothes"、"collages"、"calendar_events" 等，
        // 如果是空的，就插入默认数据
        console.log('默认分类已初始化')
      }
    } catch (err) {
      console.error('检查或插入默认数据失败:', err)
    }
  }
}) 