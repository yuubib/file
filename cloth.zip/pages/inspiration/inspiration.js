// pages/inspiration/inspiration.js
Page({
  data: {
    title: '我的衣橱',
    showDropdown: false,
    categories: [
      { id: 1, name: '随想集', count: 0 },
      { id: 2, name: '随想', count: 0 }
    ],
    inspirations: {}
  },
  
  onLoad: function() {
    // 初始化灵感分类（首次使用时）
    this.initCloudInspirationCategories();
    // 从云数据库加载分类
    this.loadInspirationCategoriesFromCloud();
  },
  
  onShow: function() {
    // 每次页面显示时刷新数据
    this.loadInspirationData();
  },
  
  // 初始化云数据库中的inspiration_categories集合
  initCloudInspirationCategories: async function() {
    try {
      const db = wx.cloud.database();
      // 检查集合中是否已有数据
      const { total } = await db.collection('inspiration_categories').count();
      
      // 如果没有数据，则初始化默认分类
      if (total === 0) {
        const defaultCategories = [
          { name: '随想集', count: 0, order: 1, createTime: new Date(), updateTime: new Date() },
          { name: '随想', count: 0, order: 2, createTime: new Date(), updateTime: new Date() }
        ];
        
        // 使用Promise.all进行批量添加
        await Promise.all(defaultCategories.map(category => 
          db.collection('inspiration_categories').add({
            data: category
          })
        ));
      }
    } catch (error) {
      console.error('初始化inspiration_categories失败:', error);
    }
  },
  
  // 从云数据库加载灵感分类
  loadInspirationCategoriesFromCloud: async function() {
    wx.showLoading({
      title: '加载中...',
    });
    
    try {
      const db = wx.cloud.database();
      // 获取所有分类，按order字段排序
      const { data: categories } = await db.collection('inspiration_categories')
        .orderBy('order', 'asc')
        .get();
      
      // 将数据库中的_id映射为前端使用的id
      const mappedCategories = categories.map(category => ({
        id: category._id, // 使用云数据库的_id作为前端id
        _id: category._id, // 同时保留_id以便操作
        name: category.name,
        count: category.count || 0,
        order: category.order
      }));
      
      // 更新数据
      this.setData({ categories: mappedCategories });
      
      wx.hideLoading();
    } catch (error) {
      console.error('加载云数据库灵感分类失败:', error);
      wx.hideLoading();
      
      wx.showToast({
        title: '加载分类失败',
        icon: 'none'
      });
    }
  },
  
  // 添加新的灵感分类到云数据库
  addInspirationCategoryToCloud: async function(name) {
    try {
      // 获取当前最大的order值
      const db = wx.cloud.database();
      const { data: categories } = await db.collection('inspiration_categories')
        .orderBy('order', 'desc')
        .limit(1)
        .get();
      
      const maxOrder = categories.length > 0 ? categories[0].order : 0;
      
      // 创建新分类
      const result = await db.collection('inspiration_categories').add({
        data: {
          name: name,
          count: 0,
          order: maxOrder + 1,
          createTime: new Date(),
          updateTime: new Date()
        }
      });
      
      // 重新加载分类列表
      this.loadInspirationCategoriesFromCloud();
      
      return result._id;
    } catch (error) {
      console.error('添加灵感分类失败:', error);
      throw error;
    }
  },
  
  // 更新灵感分类
  updateInspirationCategoryInCloud: async function(id, data) {
    try {
      const db = wx.cloud.database();
      
      // 添加更新时间
      data.updateTime = new Date();
      
      const result = await db.collection('inspiration_categories').doc(id).update({
        data: data
      });
      
      // 重新加载分类列表
      this.loadInspirationCategoriesFromCloud();
      
      return result;
    } catch (error) {
      console.error('更新灵感分类失败:', error);
      throw error;
    }
  },
  
  // 删除灵感分类
  deleteInspirationCategoryFromCloud: async function(id) {
    try {
      const db = wx.cloud.database();
      
      const result = await db.collection('inspiration_categories').doc(id).remove();
      
      // 重新加载分类列表
      this.loadInspirationCategoriesFromCloud();
      
      return result;
    } catch (error) {
      console.error('删除灵感分类失败:', error);
      throw error;
    }
  },
  
  // 加载灵感数据
  loadInspirationData: async function() {
    try {
      // 获取本地存储的灵感数据
      const localInspirations = wx.getStorageSync('inspirations') || {};
      
      // 从云数据库加载灵感数据
      const db = wx.cloud.database();
      let cloudInspirations = [];
      try {
        const { data } = await db.collection('inspirations').get();
        cloudInspirations = data || [];
      } catch (error) {
        console.error('加载灵感数据失败:', error);
        cloudInspirations = [];
      }
      
      // 克隆当前分类数组
      const categories = [...this.data.categories];
      
      // 创建合并后的灵感数据对象
      const inspirationsData = {};
      
      // 统计每个分类的数量和加载数据
      categories.forEach((category, index) => {
        const categoryId = category.id;
        
        // 获取该分类在云数据库中的灵感
        const categoryInspirations = cloudInspirations.filter(item => item.categoryId === categoryId);
        const cloudCount = categoryInspirations.length;
        
        // 设置总数 (暂时使用云数据库的数量，实际项目中可能需要合并处理)
        categories[index].count = cloudCount;
        
        // 创建该分类的灵感数组
        inspirationsData[categoryId] = categoryInspirations.map(item => ({
          id: item._id,
          title: item.title,
          image: item.image,
          tags: item.tags,
          note: item.note,
          link: item.link,
          createdAt: item.createdAt
        }));
        
        // 同时更新云数据库中的计数
        if (category._id) {
          this.updateCategoryCountInCloud(category._id, cloudCount);
        }
      });
      
      this.setData({ 
        categories,
        inspirations: inspirationsData
      });
    } catch (error) {
      console.error('加载灵感数据失败:', error);
    }
  },
  
  // 更新云数据库中的分类计数
  updateCategoryCountInCloud: async function(categoryId, count) {
    try {
      const db = wx.cloud.database();
      await db.collection('inspiration_categories').doc(categoryId).update({
        data: {
          count: count,
          updateTime: new Date()
        }
      });
    } catch (error) {
      console.error('更新分类计数失败:', error, categoryId);
    }
  },
  
  // 切换下拉菜单
  toggleDropdown: function() {
    this.setData({
      showDropdown: !this.data.showDropdown
    });
  },
  
  // 关闭衣橱切换弹窗
  closeWardrobePopup: function() {
    this.setData({
      showDropdown: false
    });
  },
  
  // 阻止事件冒泡
  stopPropagation: function() {
    return false;
  },
  
  // 显示开发中的功能提示
  showDevelopingFeature: function(featureName) {
    wx.showToast({
      title: `${featureName}功能开发中`,
      icon: 'none'
    });
  },
  
  // 选择衣橱
  selectWardrobe: function() {
    // 关闭弹窗
    this.closeWardrobePopup();
    this.showDevelopingFeature('切换衣橱');
  },
  
  // 添加衣橱
  addWardrobe: function() {
    this.showDevelopingFeature('创建衣橱');
  },
  
  // 衣橱设置
  wardrobeSettings: function() {
    this.showDevelopingFeature('衣橱设置');
  },
  
  // 添加灵感项
  addInspirationItem: function(e) {
    const categoryId = e.currentTarget.dataset.id;
    const category = this.data.categories.find(c => c.id === categoryId);
    
    // 显示与浮动添加按钮一致的弹窗
    wx.showActionSheet({
      itemList: ['创建灵感', '从相册添加', '从相册批量添加'],
      success: (res) => {
        const index = res.tapIndex;
        if (index === 0) {
          // 创建灵感 - 跳转到灵感创建页面
          wx.navigateTo({
            url: '../add_inspiration/add_inspiration?categoryId=' + categoryId + '&categoryName=' + category.name
          });
        } else if (index === 1) {
          // 从相册添加 - 直接使用当前分类
          this.chooseMediaFromAlbum(categoryId, category.name);
        } else if (index === 2) {
          // 从相册批量添加 - 直接使用当前分类
          this.batchAddFromAlbumWithCategory(categoryId, category.name);
        }
      }
    });
  },
  
  // 从相册选择单张照片
  chooseFromAlbum: function() {
    // 直接调用wx.chooseMedia，不需要先选择分类
    wx.chooseMedia({
      count: 1, // 单张选择
      mediaType: ['image'],
      sourceType: ['album'],
      success: (res) => {
        // 将临时文件路径保存到全局数据
        const app = getApp();
        if (!app.globalData) {
          app.globalData = {};
        }
        const tempImagePath = res.tempFiles[0].tempFilePath;
        app.globalData.tempInspirationImage = tempImagePath;
        
        // 直接跳转到灵感添加页面，不带分类ID和名称，只标记有图片
        wx.navigateTo({
          url: `../add_inspiration/add_inspiration?hasImage=true`
        });
      }
    });
  },
  
  // 从相册选择照片并指定分类
  chooseMediaFromAlbum: function(categoryId, categoryName) {
    wx.chooseMedia({
      count: 1, // 单张选择
      mediaType: ['image'],
      sourceType: ['album'],
      success: (res) => {
        // 将临时文件路径保存到全局数据
        const app = getApp();
        if (!app.globalData) {
          app.globalData = {};
        }
        const tempImagePath = res.tempFiles[0].tempFilePath;
        app.globalData.tempInspirationImage = tempImagePath;
        
        // 跳转到灵感添加页面，并传递分类信息和标记表示有图片
        wx.navigateTo({
          url: `../add_inspiration/add_inspiration?categoryId=${categoryId}&categoryName=${categoryName}&hasImage=true`
        });
      }
    });
  },
  
  // 记录想法功能处理
  recordThought: function(categoryId) {
    // 如果没有指定分类ID，弹出分类选择
    if (!categoryId) {
      wx.showActionSheet({
        itemList: this.data.categories.map(cat => cat.name),
        success: (res) => {
          // 选择的分类
          const selectedCategory = this.data.categories[res.tapIndex];
          // 选择完分类后，跳转到灵感添加页面
          wx.navigateTo({
            url: `../add_inspiration/add_inspiration?categoryId=${selectedCategory.id}&categoryName=${selectedCategory.name}`
          });
        }
      });
    } else {
      // 获取分类名称
      const category = this.data.categories.find(c => c.id === categoryId);
      // 直接跳转到灵感添加页面
      wx.navigateTo({
        url: `../add_inspiration/add_inspiration?categoryId=${categoryId}&categoryName=${category ? category.name : ''}`
      });
    }
  },
  
  // 处理添加按钮点击
  onAddButtonTap: function() {
    // 在底部显示操作菜单，与图片一致
    wx.showActionSheet({
      itemList: ['创建灵感', '从相册添加', '从相册批量添加', '创建分类'],
      success: (res) => {
        const index = res.tapIndex;
        if (index === 0) {
          // 创建灵感 - 跳转到分类选择
          this.recordThought();
        } else if (index === 1) {
          // 从相册添加
          this.chooseFromAlbum();
        } else if (index === 2) {
          // 从相册批量添加
          this.batchAddFromAlbum();
        } else if (index === 3) {
          // 创建分类
          this.createCategory();
        }
      }
    });
  },
  
  // 创建新分类
  createCategory: function() {
    wx.showModal({
      title: '创建分类',
      editable: true,
      placeholderText: '请输入分类名称',
      content: '',
      success: async (res) => {
        if (res.confirm && res.content.trim()) {
          wx.showLoading({
            title: '创建中...'
          });
          
          try {
            // 添加到云数据库
            await this.addInspirationCategoryToCloud(res.content.trim());
            
            wx.hideLoading();
            wx.showToast({
              title: '创建成功',
              icon: 'success'
            });
          } catch (error) {
            wx.hideLoading();
            wx.showToast({
              title: '创建失败',
              icon: 'none'
            });
          }
        }
      }
    });
  },
  
  // 从相册批量添加
  batchAddFromAlbum: function() {
    // 直接从相册批量选择，不需要先选择分类
    wx.chooseMedia({
      count: 9, // 可选择的图片数量，设为9张
      mediaType: ['image'],
      sourceType: ['album'],
      success: (res) => {
        if (res.tempFiles && res.tempFiles.length > 0) {
          // 将第一张图片路径保存到全局数据，并跳转到添加页面
          const app = getApp();
          if (!app.globalData) {
            app.globalData = {};
          }
          
          // 保存所有选择的图片路径
          app.globalData.tempInspirationBatchImages = res.tempFiles.map(file => file.tempFilePath);
          
          // 设置第一张为当前图片
          app.globalData.tempInspirationImage = res.tempFiles[0].tempFilePath;
          
          // 记录批量导入的图片数量和当前索引
          app.globalData.batchImageCount = res.tempFiles.length;
          app.globalData.batchCurrentIndex = 0;
          
          // 跳转到灵感添加页面，不传递分类信息，只传递批量标记
          wx.navigateTo({
            url: `../add_inspiration/add_inspiration?hasImage=true&isBatch=true&batchTotal=${res.tempFiles.length}`
          });
        }
      }
    });
  },
  
  // 从相册批量添加并指定分类
  batchAddFromAlbumWithCategory: function(categoryId, categoryName) {
    wx.chooseMedia({
      count: 9, // 可选择的图片数量，设为9张
      mediaType: ['image'],
      sourceType: ['album'],
      success: (res) => {
        if (res.tempFiles && res.tempFiles.length > 0) {
          // 将第一张图片路径保存到全局数据，并跳转到添加页面
          const app = getApp();
          if (!app.globalData) {
            app.globalData = {};
          }
          
          // 保存所有选择的图片路径
          app.globalData.tempInspirationBatchImages = res.tempFiles.map(file => file.tempFilePath);
          
          // 设置第一张为当前图片
          app.globalData.tempInspirationImage = res.tempFiles[0].tempFilePath;
          
          // 记录批量导入的图片数量和当前索引
          app.globalData.batchImageCount = res.tempFiles.length;
          app.globalData.batchCurrentIndex = 0;
          
          // 跳转到灵感添加页面，传递分类信息和批量标记
          wx.navigateTo({
            url: `../add_inspiration/add_inspiration?categoryId=${categoryId}&categoryName=${categoryName}&hasImage=true&isBatch=true&batchTotal=${res.tempFiles.length}`
          });
        }
      }
    });
  },
  
  // 显示分类设置
  showCategorySettings: function(e) {
    const categoryId = e.currentTarget.dataset.id;
    const category = this.data.categories.find(cat => cat.id === categoryId);
    
    wx.showActionSheet({
      itemList: ['查看全部', '编辑分类', '删除分类'],
      success: (res) => {
        const index = res.tapIndex;
        if (index === 0) {
          // 查看该分类下的所有灵感
          this.showDevelopingFeature('查看全部');
        } else if (index === 1) {
          // 编辑分类
          this.editCategory(category);
        } else if (index === 2) {
          // 删除分类
          this.deleteCategory(category);
        }
      }
    });
  },
  
  // 编辑分类
  editCategory: function(category) {
    wx.showModal({
      title: '编辑分类',
      editable: true,
      placeholderText: '请输入分类名称',
      content: category.name,
      success: async (res) => {
        if (res.confirm && res.content.trim()) {
          wx.showLoading({
            title: '更新中...'
          });
          
          try {
            // 更新云数据库
            await this.updateInspirationCategoryInCloud(category._id, {
              name: res.content.trim()
            });
            
            wx.hideLoading();
            wx.showToast({
              title: '更新成功',
              icon: 'success'
            });
          } catch (error) {
            wx.hideLoading();
            wx.showToast({
              title: '更新失败',
              icon: 'none'
            });
          }
        }
      }
    });
  },
  
  // 删除分类
  deleteCategory: function(category) {
    wx.showModal({
      title: '删除分类',
      content: `确认删除分类「${category.name}」吗？该分类下的所有灵感也将被删除。`,
      success: async (res) => {
        if (res.confirm) {
          wx.showLoading({
            title: '删除中...'
          });
          
          try {
            const db = wx.cloud.database();
            
            // 1. 删除分类下的所有灵感
            const { data: inspirations } = await db.collection('inspirations')
              .where({ categoryId: category.id })
              .get();
            
            // 批量删除灵感
            await Promise.all(inspirations.map(insp => 
              db.collection('inspirations').doc(insp._id).remove()
            ));
            
            // 2. 删除分类
            await this.deleteInspirationCategoryFromCloud(category._id);
            
            // 3. 更新本地存储
            const localInspirations = wx.getStorageSync('inspirations') || {};
            delete localInspirations[category.id];
            wx.setStorageSync('inspirations', localInspirations);
            
            wx.hideLoading();
            wx.showToast({
              title: '删除成功',
              icon: 'success'
            });
          } catch (error) {
            console.error('删除分类失败', error);
            wx.hideLoading();
            wx.showToast({
              title: '删除失败',
              icon: 'none'
            });
          }
        }
      }
    });
  },
  
  // 查看灵感详情
  viewInspirationDetail: function() {
    this.showDevelopingFeature('灵感详情');
  }
}) 