// pages/save_collage/save_collage.js
/**
 * 拼贴保存 / 编辑页
 * 2025‑04‑14  重构：模块化、async‑await、性能优化
 */
const app = getApp();
const db = app.globalData.db;

Page({
  /* ----------------------------- data ----------------------------- */
  data: {
    id: null, // 拼贴 _id，存在即编辑模式
    isEditMode: false,

    collageImage: '', // 源路径：本地 temp / cloud fileID
    collageImageDisplay: '', // <image> 可渲染地址

    categories: [], // 场合分类
    selectedCategoryId: '',
    selectedCategory: '休闲',

    seasons: ['春季', '夏季', '秋季', '冬季', '四季'],
    selectedSeason: '四季',

    tags: [],
    tagInput: '',
    notes: '',

    // UI 状态
    showCategorySelector: false,
    showSeasonSelector: false,
    showTagSelector: false,
    isSaving: false,
  },

  /* -------------------------- 生命周期 --------------------------- */
  async onLoad(options) {
    // 编辑模式
    if (options.id) {
      this.setData({
        id: options.id,
        isEditMode: true
      });
      wx.setNavigationBarTitle({
        title: '编辑拼贴'
      });
      await this.loadCollage(options.id);
    }

    // 新增模式入参
    if (options.collageImage) {
      const raw = decodeURIComponent(options.collageImage);
      const display = await this.getDisplaySrc(raw);
      this.setData({
        collageImage: raw,
        collageImageDisplay: display
      });
    }
    if (options.categoryId) {
      this.setData({
        selectedCategoryId: options.categoryId
      });
    }

    // 加载场合分类
    this.loadCategories();
  },

  /* ------------------------- 工具函数 --------------------------- */
  /** fileID → 临时 URL；本地路径直接返回 */
  async getDisplaySrc(path) {
    if (/^cloud:/.test(path)) {
      const {
        fileList
      } = await wx.cloud.getTempFileURL({
        fileList: [{
          fileID: path,
          maxAge: 3600
        }]
      });
      return fileList[0]?.tempFileURL || '';
    }
    return path;
  },

  /* ------------------------- 数据加载 --------------------------- */
  /** 读取已有拼贴并回填 */
  async loadCollage(id) {
    try {
      wx.showLoading({
        title: '加载中...'
      });
      const {
        data
      } = await db.collection('collages').doc(id).get();
      if (!data) throw new Error('not found');

      const display = await this.getDisplaySrc(data.image);
      this.setData({
        collageImage: data.image,
        collageImageDisplay: display,
        selectedCategoryId: data.categoryId,
        selectedCategory: data.categoryName,
        selectedSeason: data.season,
        tags: data.tags || [],
        notes: data.notes || '',
      });
    } catch (err) {
      console.error('loadCollage error', err);
      wx.showToast({
        title: '加载失败',
        icon: 'none'
      });
    } finally {
      wx.hideLoading();
    }
  },

  /** 加载场合分类 */
  async loadCategories() {
    wx.showLoading({
      title: '加载中...'
    });
    try {
      const {
        data
      } = await db.collection('outfit_categories').orderBy('order', 'asc').get();
      this.setData({
        categories: data
      });

      // 自动选中
      if (this.data.selectedCategoryId) {
        const cat = data.find(c => c._id === this.data.selectedCategoryId);
        if (cat) this.setData({
          selectedCategory: cat.name
        });
      }
    } catch (e) {
      console.error('loadCategories error', e);
      wx.showToast({
        title: '加载分类失败',
        icon: 'none'
      });
    } finally {
      wx.hideLoading();
    }
  },

  /* ------------------------- 图片操作 --------------------------- */
  previewImage() {
    if (this.data.collageImageDisplay) {
      wx.previewImage({
        urls: [this.data.collageImageDisplay]
      });
    }
  },

  /* ------------------------- 保存拼贴 --------------------------- */
  async saveCollage() {
    if (this.data.isSaving) return;
    const {
      isEditMode,
      collageImage,
      selectedCategoryId
    } = this.data;

    if (!collageImage) return wx.showToast({
      title: '没有拼图数据',
      icon: 'none'
    });
    if (!selectedCategoryId) return wx.showToast({
      title: '请选择场合',
      icon: 'none'
    });

    this.setData({
      isSaving: true
    });
    wx.showLoading({
      title: isEditMode ? '更新中...' : '保存中...',
      mask: true
    });

    try {
      // 1) 处理主图上传
      let fileID = collageImage;
      if (!/^cloud:/.test(collageImage)) {
        fileID = await this.uploadCollageImage(collageImage);
      }

      // 2) 组装数据
      const payload = {
        image: fileID,
        categoryId: selectedCategoryId,
        categoryName: this.data.selectedCategory,
        season: this.data.selectedSeason,
        tags: this.data.tags,
        notes: this.data.notes,
        updateTime: db.serverDate(),
      };

      // 3) 写库
      if (isEditMode) {
        await db.collection('collages').doc(this.data.id).update({
          data: payload
        });
      } else {
        payload.createTime = db.serverDate();
        await db.collection('collages').add({
          data: payload
        });
      }

      // 4) 结束
      wx.hideLoading();
      wx.showToast({
        title: isEditMode ? '已更新' : '保存成功',
        icon: 'success',
        success: () => setTimeout(() => wx.switchTab({
          url: '/pages/index/index'
        }), 1200),
      });
    } catch (err) {
      console.error('saveCollage error', err);
      wx.showToast({
        title: '保存失败',
        icon: 'none'
      });
    } finally {
      wx.hideLoading();
      this.setData({
        isSaving: false
      });
    }
  },

  /** 上传图片到云存储（返回 fileID） */
  uploadCollageImage(filePath) {
    return new Promise((resolve, reject) => {
      const ext = filePath.match(/\.\w+$/)?.[0] || '.png';
      const cloudPath = `collages/${Date.now()}_${Math.random().toString(36).slice(2)}${ext}`;

      wx.cloud.uploadFile({
        cloudPath,
        filePath,
        success: ({
          fileID
        }) => resolve(fileID),
        fail: reject,
      });
    });
  },

  /* ------------------------- 分类选择 --------------------------- */
  showCategorySelector() {
    this.setData({
      showCategorySelector: true
    });
  },
  closeCategorySelector() {
    this.setData({
      showCategorySelector: false
    });
  },
  selectCategory({
    currentTarget
  }) {
    const {
      id,
      name
    } = currentTarget.dataset;
    this.setData({
      selectedCategoryId: id,
      selectedCategory: name,
      showCategorySelector: false
    });
  },

  /* ------------------------- 季节选择 --------------------------- */
  showSeasonSelector() {
    this.setData({
      showSeasonSelector: true
    });
  },
  closeSeasonSelector() {
    this.setData({
      showSeasonSelector: false
    });
  },
  selectSeason({
    currentTarget
  }) {
    this.setData({
      selectedSeason: currentTarget.dataset.season,
      showSeasonSelector: false
    });
  },

  /* ------------------------- 标签管理 --------------------------- */
  showTagSelector() {
    this.setData({
      showTagSelector: true,
      tagInput: ''
    });
  },
  closeTagSelector() {
    this.setData({
      showTagSelector: false
    });
  },
  onTagInput({
    detail
  }) {
    this.setData({
      tagInput: detail.value
    });
  },
  addTag() {
    const tag = this.data.tagInput.trim();
    if (!tag) return wx.showToast({
      title: '标签不能为空',
      icon: 'none'
    });
    if (this.data.tags.includes(tag)) return wx.showToast({
      title: '标签已存在',
      icon: 'none'
    });
    this.setData({
      tags: [...this.data.tags, tag],
      tagInput: ''
    });
  },
  removeTag({
    currentTarget
  }) {
    const idx = currentTarget.dataset.index;
    const tags = [...this.data.tags];
    tags.splice(idx, 1);
    this.setData({
      tags
    });
  },
  confirmTags() {
    this.closeTagSelector();
  },

  /* ------------------------- 备注 --------------------------- */
  addNote() {
    this.promptNote();
  },
  editNote() {
    this.promptNote();
  },
  promptNote() {
    wx.showModal({
      title: '备注',
      editable: true,
      placeholderText: '请输入备注内容',
      content: this.data.notes,
      success: ({
        confirm,
        content
      }) => {
        if (confirm) this.setData({
          notes: content || ''
        });
      },
    });
  },

  /* ------------------------- 空函数阻止冒泡 --------------------------- */
  stopPropagation() {},
});