Page({
  data: {
    title: '我的衣橱',
    showDropdown: false,
    year: 2025,
    month: 3,
    day: 15,
    selectedDate: '2025-03-15',
    weekdays: ['日', '一', '二', '三', '四', '五', '六'],
    dateList: [],
    showYearMonthPicker: false,
    years: [],
    months: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
    records: {},  // 存储日期对应的记录
    
    // 新增属性
    showActionMenu: false,
    showDatePicker: false,
    yearArray: [],
    monthArray: [],
    dayArray: [],
    pickerValue: [0, 0, 0]
  },
  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 获取当前日期
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth() + 1;
    const day = now.getDate();
    
    const formattedMonth = this.formatNumber(month);
    const formattedDay = this.formatNumber(day);
    const selectedDate = `${year}-${formattedMonth}-${formattedDay}`;
    
    // 设置当前选中的日期和月份
    this.setData({
      year: year,
      month: month,
      day: day,
      selectedYear: year.toString(),
      selectedMonth: formattedMonth,
      selectedDay: formattedDay,
      selectedDate: selectedDate
    });
    
    // 初始化日期选择器数据
    this.initDatePickerData(year, month, day);
    
    // 生成日期表格
    this.generateDateList();
    
    // 加载记录
    this.loadRecords();
  },
  
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // 每次显示页面时重新加载记录，以获取最新数据
    this.loadRecords();
  },
  
  // 生成日历数据
  generateDateList: function () {
    const { year, month } = this.data;
    const dateList = [];
    
    // 获取当月第一天和最后一天
    const firstDay = new Date(year, month - 1, 1);
    const lastDay = new Date(year, month, 0);
    
    // 获取当月第一天是星期几
    const firstDayWeek = firstDay.getDay();
    
    // 获取当月的总天数
    const totalDays = lastDay.getDate();
    
    // 获取上个月的最后几天
    const lastMonthLastDay = new Date(year, month - 1, 0).getDate();
    
    // 填充日历数组，一个月的数据用二维数组表示，每行代表一个星期
    let dayCount = 1;
    let nextMonthDay = 1;
    
    // 按周填充日历
    for (let week = 0; week < 6; week++) {
      const weekDays = [];
      for (let day = 0; day < 7; day++) {
        let dateObj;
        
        if (week === 0 && day < firstDayWeek) {
          // 上个月的日期
          const prevMonthDay = lastMonthLastDay - (firstDayWeek - day - 1);
          const prevMonth = month === 1 ? 12 : month - 1;
          const prevYear = month === 1 ? year - 1 : year;
          dateObj = {
            year: prevYear,
            month: prevMonth,
            day: prevMonthDay,
            date: `${prevYear}-${this.formatNumber(prevMonth)}-${this.formatNumber(prevMonthDay)}`,
            currentMonth: false,
            isToday: false,
            selected: false
          };
        } else if (dayCount <= totalDays) {
          // 当月的日期
          dateObj = {
            year: year,
            month: month,
            day: dayCount,
            date: `${year}-${this.formatNumber(month)}-${this.formatNumber(dayCount)}`,
            currentMonth: true,
            isToday: this.isToday(year, month, dayCount),
            selected: dayCount === this.data.day
          };
          dayCount++;
        } else {
          // 下个月的日期
          const nextMonth = month === 12 ? 1 : month + 1;
          const nextYear = month === 12 ? year + 1 : year;
          dateObj = {
            year: nextYear,
            month: nextMonth,
            day: nextMonthDay,
            date: `${nextYear}-${this.formatNumber(nextMonth)}-${this.formatNumber(nextMonthDay)}`,
            currentMonth: false,
            isToday: false,
            selected: false
          };
          nextMonthDay++;
        }
        
        weekDays.push(dateObj);
      }
      dateList.push(weekDays);
      
      // 如果已经填完了当月所有日期和下个月的前几天，就不再继续循环
      if (dayCount > totalDays && week >= 4) {
        break;
      }
    }
    
    this.setData({ dateList });
  },
  
  // 判断是否是今天
  isToday: function (year, month, day) {
    const today = new Date();
    return year === today.getFullYear() && month === today.getMonth() + 1 && day === today.getDate();
  },
  
  // 选择日期
  selectDate: function (e) {
    const { date } = e.currentTarget.dataset;
    const [year, month, day] = date.split('-').map(item => parseInt(item));
    
    // 如果选择的是上个月或下个月的日期，则切换到对应月份
    if (month !== this.data.month) {
      this.setData({
        year,
        month,
        day: parseInt(day)
      }, () => {
        this.generateDateList();
        // 加载选中日期的记录
        this.loadRecords();
      });
    } else {
      // 更新选中状态
      this.setData({
        day: parseInt(day),
        selectedDate: date
      });
      
      // 更新日历数据中的选中状态
      const dateList = this.data.dateList;
      dateList.forEach(week => {
        week.forEach(dateObj => {
          dateObj.selected = dateObj.date === date;
        });
      });
      
      this.setData({ 
        dateList,
        selectedYear: year.toString(),
        selectedMonth: this.formatNumber(month),
        selectedDay: this.formatNumber(day)
      }, () => {
        // 加载选中日期的记录
        this.loadRecords();
      });
    }
  },
  
  // 上个月
  prevMonth: function () {
    let { year, month } = this.data;
    if (month === 1) {
      year--;
      month = 12;
    } else {
      month--;
    }
    
    const formattedMonth = this.formatNumber(month);
    
    this.setData({
      year,
      month,
      day: 1,
      selectedYear: year.toString(),
      selectedMonth: formattedMonth,
      selectedDay: '01',
      selectedDate: `${year}-${formattedMonth}-01`
    }, () => {
      this.generateDateList();
      this.loadRecords();
    });
  },
  
  // 下个月
  nextMonth: function () {
    let { year, month } = this.data;
    if (month === 12) {
      year++;
      month = 1;
    } else {
      month++;
    }
    
    const formattedMonth = this.formatNumber(month);
    
    this.setData({
      year,
      month,
      day: 1,
      selectedYear: year.toString(),
      selectedMonth: formattedMonth,
      selectedDay: '01',
      selectedDate: `${year}-${formattedMonth}-01`
    }, () => {
      this.generateDateList();
      this.loadRecords();
    });
  },
  
  // 显示/隐藏年月选择器
  toggleYearMonthPicker: function () {
    this.setData({
      showYearMonthPicker: !this.data.showYearMonthPicker
    });
  },
  
  // 选择年份
  selectYear: function (e) {
    const year = parseInt(e.currentTarget.dataset.year);
    this.setData({
      year,
      showYearMonthPicker: false
    }, () => {
      this.generateDateList();
    });
  },
  
  // 选择月份
  selectMonth: function (e) {
    const month = parseInt(e.currentTarget.dataset.month);
    this.setData({
      month,
      showYearMonthPicker: false
    }, () => {
      this.generateDateList();
    });
  },
  
  // 初始化日期选择器数据
  initDatePickerData: function(year, month, day) {
    // 生成年份数组，从当前年份往前2年，往后5年
    const currentYear = new Date().getFullYear();
    const yearArray = [];
    for (let i = currentYear - 2; i <= currentYear + 5; i++) {
      yearArray.push(i);
    }
    
    // 生成月份数组，从1月到12月
    const monthArray = [];
    for (let i = 1; i <= 12; i++) {
      monthArray.push(i);
    }
    
    // 生成天数数组，根据选中的年月生成对应的天数
    const dayArray = this.getDaysInMonth(year, month);
    
    // 设置picker的默认值
    let yearIndex = yearArray.indexOf(year);
    if (yearIndex === -1) yearIndex = 0;
    
    let monthIndex = month - 1;
    let dayIndex = day - 1;
    
    this.setData({
      yearArray,
      monthArray,
      dayArray,
      pickerValue: [yearIndex, monthIndex, dayIndex]
    });
  },
  
  // 获取某个月的天数
  getDaysInMonth: function(year, month) {
    const days = new Date(year, month, 0).getDate();
    const dayArray = [];
    for (let i = 1; i <= days; i++) {
      dayArray.push(i);
    }
    return dayArray;
  },
  
  // 显示/隐藏日期选择器
  showDatePicker: function() {
    this.setData({
      showDatePicker: true
    });
  },
  
  // 日期选择器变化事件
  onPickerChange: function(e) {
    const values = e.detail.value;
    const year = this.data.yearArray[values[0]];
    const month = this.data.monthArray[values[1]];
    
    // 当年月变化时，需要重新计算该月的天数
    if (year !== this.data.yearArray[this.data.pickerValue[0]] || 
        month !== this.data.monthArray[this.data.pickerValue[1]]) {
      const dayArray = this.getDaysInMonth(year, month);
      
      // 如果选中的日期超过了新月份的天数，则调整为新月份的最后一天
      let dayIndex = values[2];
      if (dayIndex >= dayArray.length) {
        dayIndex = dayArray.length - 1;
      }
      
      this.setData({
        dayArray,
        pickerValue: [values[0], values[1], dayIndex]
      });
    } else {
      this.setData({
        pickerValue: values
      });
    }
  },
  
  // 确认日期选择
  confirmDatePicker: function() {
    const values = this.data.pickerValue;
    const year = this.data.yearArray[values[0]];
    const month = this.data.monthArray[values[1]];
    const day = this.data.dayArray[values[2]];
    
    const formattedMonth = this.formatNumber(month);
    const formattedDay = this.formatNumber(day);
    
    this.setData({
      year,
      month,
      day,
      selectedYear: year.toString(),
      selectedMonth: formattedMonth,
      selectedDay: formattedDay,
      selectedDate: `${year}-${formattedMonth}-${formattedDay}`,
      showDatePicker: false
    }, () => {
      this.generateDateList();
      this.loadRecords();
    });
  },
  
  // 显示操作菜单
  showActionMenu: function() {
    this.setData({
      showActionMenu: true
    });
  },
  
  // 隐藏操作菜单
  hideActionMenu: function() {
    this.setData({
      showActionMenu: false
    });
  },
  
  // 添加天气记录
  addWeather: function() {
    console.log('添加天气记录');
    this.hideActionMenu();
    // 具体实现略
    wx.showToast({
      title: '天气记录功能开发中',
      icon: 'none'
    });
  },
  
  // 添加日记
  addDiary: function () {
    console.log('Adding diary for date:', this.data.selectedDate);
    wx.navigateTo({
      url: `/pages/add_diary/add_diary?date=${this.data.selectedDate}`
    });
  },
  
  // 添加搭配
  addOutfit: function() {
    console.log('添加搭配');
    this.hideActionMenu();
    // 跳转到搭配选择页面
    wx.navigateTo({
      url: '../index/index'
    });
  },
  
  // 添加单品
  addItem: function() {
    console.log('添加单品');
    this.hideActionMenu();
    // 跳转到衣物添加页面
    wx.navigateTo({
      url: '../wardrobe/wardrobe'
    });
  },
  
  // 添加记录
  addRecord: function () {
    wx.showActionSheet({
      itemList: ['添加穿搭', '添加笔记', '每日天气', '更多'],
      success: (res) => {
        console.log('选择了:', res.tapIndex);
        // 根据选择的选项执行不同操作
        if (res.tapIndex === 0) {
          // 添加穿搭
          this.addOutfit();
        } else if (res.tapIndex === 1) {
          // 添加笔记
          this.addNote();
        } else if (res.tapIndex === 2) {
          // 查看天气
          this.checkWeather();
        }
      }
    });
  },
  
  // 添加笔记
  addNote: function () {
    wx.showToast({
      title: '笔记功能开发中',
      icon: 'none'
    });
  },
  
  // 查看天气
  checkWeather: function () {
    wx.showToast({
      title: '天气功能开发中',
      icon: 'none'
    });
  },
  
  // 格式化数字，个位数前补0
  formatNumber: function (n) {
    n = n.toString();
    return n[1] ? n : '0' + n;
  },
  
  // 显示/隐藏标题栏下拉菜单
  toggleDropdown: function() {
    this.setData({
      showDropdown: !this.data.showDropdown
    });
  },
  
  // 关闭衣橱切换弹窗
  closeWardrobePopup: function() {
    this.setData({
      showDropdown: false
    });
  },
  
  // 阻止事件冒泡
  stopPropagation: function(e) {
    // 阻止事件冒泡
    return false;
  },
  
  // 选择衣橱
  selectWardrobe: function(e) {
    const wardrobeId = e.currentTarget.dataset.id;
    console.log('选择衣橱：', wardrobeId);
    
    // 这里可以添加切换衣橱的逻辑
    
    // 关闭弹窗
    this.closeWardrobePopup();
  },
  
  // 添加衣橱
  addWardrobe: function() {
    console.log('添加新衣橱');
    // 这里可以添加创建新衣橱的逻辑
    
    wx.showToast({
      title: '创建衣橱功能开发中',
      icon: 'none'
    });
  },
  
  // 衣橱设置
  wardrobeSettings: function() {
    console.log('衣橱设置');
    // 这里可以添加衣橱设置的逻辑
    
    wx.showToast({
      title: '衣橱设置功能开发中',
      icon: 'none'
    });
  },
  
  // Add a function to load diary entries
  loadRecords: function() {
    wx.showLoading({
      title: '加载中...',
    });
    
    const db = wx.cloud.database();
    const app = getApp();
    const userId = app.globalData.openid || 'temp_user';
    const selectedMonth = `${this.data.selectedYear}-${this.data.selectedMonth}`;
    
    // Create promises for all collections
    const diaryPromise = db.collection('diary')
      .where({
        userId: userId,
        // Filter entries where date starts with the selected year and month
        date: db.command.gte(`${selectedMonth}-01`).and(db.command.lt(`${selectedMonth}-32`))
      })
      .get();
      
    const clothesPromise = db.collection('clothes')
      .where({
        userId: userId,
        calendarDates: db.command.elemMatch(db.command.eq(selectedMonth))
      })
      .get();
      
    const collagesPromise = db.collection('collages')
      .where({
        userId: userId,
        calendarDates: db.command.elemMatch(db.command.eq(selectedMonth))
      })
      .get();
    
    // Execute all promises together
    Promise.all([diaryPromise, clothesPromise, collagesPromise])
      .then(([diaryRes, clothesRes, collagesRes]) => {
        const diaries = diaryRes.data;
        const clothes = clothesRes.data;
        const collages = collagesRes.data;
        
        console.log('Loaded diaries:', diaries.length);
        console.log('Loaded clothes:', clothes.length);
        console.log('Loaded collages:', collages.length);
        
        // Process and combine records
        const records = {};
        
        // Process diary entries
        diaries.forEach(diary => {
          if (!records[diary.date]) {
            records[diary.date] = [];
          }
          
          records[diary.date].push({
            id: diary._id,
            type: 'diary',
            content: diary.content,
            images: diary.images || [],
            time: diary.time || '',
            weather: diary.weather || '',
            createdAt: diary.createdAt
          });
        });
        
        // Process clothing items
        clothes.forEach(item => {
          if (item.calendarDates) {
            item.calendarDates.forEach(date => {
              if (!records[date]) {
                records[date] = [];
              }
              
              records[date].push({
                id: item._id,
                type: 'clothes',
                itemId: item._id,
                image: item.image,
                name: item.name,
                createdAt: item.createdAt
              });
            });
          }
        });
        
        // Process outfit collages
        collages.forEach(collage => {
          if (collage.calendarDates) {
            collage.calendarDates.forEach(date => {
              if (!records[date]) {
                records[date] = [];
              }
              
              records[date].push({
                id: collage._id,
                type: 'collage',
                outfitId: collage._id,
                image: collage.image,
                name: collage.name,
                createdAt: collage.createdAt
              });
            });
          }
        });
        
        // Sort records by creation time (newest first)
        Object.keys(records).forEach(date => {
          records[date].sort((a, b) => {
            return new Date(b.createdAt) - new Date(a.createdAt);
          });
        });
        
        this.setData({
          records: records
        });
        
        wx.hideLoading();
      })
      .catch(err => {
        console.error('Failed to load records:', err);
        wx.hideLoading();
        
        wx.showToast({
          title: '加载记录失败',
          icon: 'none'
        });
      });
  },
  
  // Add functions to handle viewing different record types
  previewImage: function(e) {
    const src = e.currentTarget.dataset.src;
    const images = e.currentTarget.dataset.images;
    
    wx.previewImage({
      current: src,
      urls: images
    });
  },
  
  viewClothingItem: function(e) {
    const id = e.currentTarget.dataset.id;
    
    wx.navigateTo({
      url: `/pages/detail/detail?id=${id}`
    });
  },
  
  viewOutfit: function(e) {
    const id = e.currentTarget.dataset.id;
    
    wx.navigateTo({
      url: `/pages/outfit_detail/outfit_detail?id=${id}`
    });
  },

  // 编辑日记
  editDiary: function(e) {
    const diaryId = e.currentTarget.dataset.id;
    const date = e.currentTarget.dataset.date;
    
    wx.navigateTo({
      url: `/pages/add_diary/add_diary?id=${diaryId}&date=${date}&isEdit=true`
    });
  },
  
  // 显示删除确认对话框
  showDeleteConfirm: function(e) {
    const diaryId = e.currentTarget.dataset.id;
    const date = e.currentTarget.dataset.date;
    
    wx.showModal({
      title: '删除确认',
      content: '确定要删除这条日记吗？删除后无法恢复。',
      confirmColor: '#ff4d4f',
      success: (res) => {
        if (res.confirm) {
          this.deleteDiary(diaryId, date);
        }
      }
    });
  },
  
  // 删除日记
  deleteDiary: function(diaryId, date) {
    wx.showLoading({
      title: '删除中...',
    });
    
    const db = wx.cloud.database();
    
    db.collection('diary').doc(diaryId).remove()
      .then(res => {
        wx.hideLoading();
        
        if (res.stats.removed > 0) {
          wx.showToast({
            title: '删除成功',
            icon: 'success'
          });
          
          // 从本地记录中删除
          if (this.data.records[date]) {
            const updatedRecords = [...this.data.records[date]];
            const index = updatedRecords.findIndex(item => item.id === diaryId);
            
            if (index !== -1) {
              updatedRecords.splice(index, 1);
              
              const newRecords = { ...this.data.records };
              if (updatedRecords.length === 0) {
                // 如果没有记录了，则删除该日期的记录数组
                delete newRecords[date];
              } else {
                newRecords[date] = updatedRecords;
              }
              
              this.setData({
                records: newRecords
              });
            }
          }
        } else {
          wx.showToast({
            title: '删除失败',
            icon: 'none'
          });
        }
      })
      .catch(err => {
        console.error('删除日记失败:', err);
        wx.hideLoading();
        
        wx.showToast({
          title: '删除失败',
          icon: 'none'
        });
      });
  }
}) 