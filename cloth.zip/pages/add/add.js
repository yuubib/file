// pages/add/add.js
/**
 * 新增 / 编辑 单品
 * 2025‑04‑14  重构：代码规范化、性能优化、Bug 修复
 */
const app = getApp();
const db = app.globalData.db;

Page({
  /* ----------------------------- data ----------------------------- */
  data: {
    // 标识
    id: null,
    isEditMode: false,

    // 分类
    categoryId: null,
    categoryName: '',
    subcategoryId: null,
    subcategoryName: '',

    // 图片
    imagePath: '',
    isMultiple: false,

    // 列表数据
    categories: [],
    subcategories: [],

    // 表单
    formData: {
      name: '',
      season: '四季',
      color: '',
      location: '',
      brand: '',
      price: '',
      size: '',
      link: '',
      purchaseDate: '',
      tags: '',
      notes: [],
    },

    /* ---------- UI 相关 ---------- */
    showDatePicker: false,
    currentDate: '',

    // 备注
    noteImages: [],
    noteText: '',
    showNoteInput: false,

    // 颜色选择
    showColorPicker: false,
    selectedColor: '',
    colorOptions: ['黑色', '白色', '灰色', '红色', '蓝色', '绿色', '黄色', '紫色', '粉色', '棕色', '自定义颜色'],
    isCustomColor: false,
    customColorText: '',

    colorMap: {
      黑色: '#000000',
      白色: '#FFFFFF',
      灰色: '#808080',
      红色: '#FF0000',
      蓝色: '#0000FF',
      绿色: '#008000',
      黄色: '#FFFF00',
      紫色: '#800080',
      粉色: '#FFC0CB',
      棕色: '#A52A2A',
    },
  },

  /* -------------------------- 生命周期 --------------------------- */
  async onLoad(options) {
    try {
      await this.loadCategories();

      // 编辑模式
      if (options.id) {
        this.setData({
          id: options.id,
          isEditMode: true
        });
        wx.setNavigationBarTitle({
          title: '编辑衣物'
        });
        await this.loadItem(options.id);
      }

      // 分类预选
      if (options.categoryId) {
        const cat = this.data.categories.find(c => c._id === options.categoryId);
        this.setData({
          categoryId: options.categoryId,
          categoryName: cat?.name || '未知分类',
        });
        this.loadSubcategories(options.categoryId);
      }

      // 预设图片
      if (options.imagePath) {
        this.setData({
          imagePath: decodeURIComponent(options.imagePath)
        });
      }

      // 多图模式
      if (options.multiple === 'true') {
        const paths = app.globalData.tempImagePaths || [];
        this.setData({
          isMultiple: true,
          imagePath: paths[0] || this.data.imagePath
        });
      }
    } catch (e) {
      console.error('onLoad error', e);
    }
  },

  /* ------------------------- 数据加载 --------------------------- */
  /** 分类列表 */
  async loadCategories() {
    const {
      data
    } = await db.collection('categories').orderBy('order', 'asc').get();
    this.setData({
      categories: data
    });
  },

  /** 子分类列表 */
  async loadSubcategories(categoryId) {
    if (!categoryId) return;
    wx.showLoading({
      title: '加载子分类...'
    });
    try {
      const {
        data
      } = await db.collection('subcategories').where({
        parentId: categoryId
      }).orderBy('order', 'asc').get();
      this.setData({
        subcategories: data
      });
    } catch (e) {
      wx.showToast({
        title: '加载子分类失败',
        icon: 'none'
      });
    } finally {
      wx.hideLoading();
    }
  },

  /** 读取单品 */
  async loadItem(id) {
    wx.showLoading({
      title: '加载中...'
    });
    try {
      const {
        data
      } = await db.collection('clothes').doc(id).get();
      if (!data) throw new Error('not found');

      const {
        categoryId,
        categoryName,
        subcategoryId,
        subcategoryName,
        image,
        name,
        season,
        color,
        location,
        brand,
        price,
        size,
        link,
        purchaseDate,
        tags,
        notes,
      } = data;

      this.setData({
        categoryId,
        categoryName,
        subcategoryId,
        subcategoryName,
        imagePath: image,
        formData: {
          name,
          season,
          color,
          location,
          brand,
          price,
          size,
          link,
          purchaseDate,
          tags,
          notes
        },
      });
    } catch (e) {
      wx.showToast({
        title: '加载失败',
        icon: 'none'
      });
      console.error('loadItem error', e);
    } finally {
      wx.hideLoading();
    }
  },

  /* ------------------------- 提交保存 --------------------------- */
  async submitItem() {
    // 基本校验
    if (!this.data.imagePath) return wx.showToast({
      title: '请添加衣物图片',
      icon: 'none'
    });
    if (!this.data.categoryId) return wx.showToast({
      title: '请选择分类',
      icon: 'none'
    });

    wx.showLoading({
      title: this.data.isEditMode ? '更新中...' : '保存中...',
      mask: true
    });
    try {
      /* 1. 图片上传 */
      let fileID = this.data.imagePath;
      if (!/^cloud:/.test(fileID)) fileID = await this.uploadImageToCloud(fileID);

      /* 2. 子分类处理 */
      let {
        subcategoryId,
        subcategoryName
      } = this.data;
      if (!subcategoryId) {
        subcategoryId = await this.ensureDefaultSubcategory(this.data.categoryId);
        subcategoryName = '未分类';
      }

      /* 3. 备注图片上传 */
      const noteImgIDs = await Promise.all(this.data.noteImages.map(p => this.uploadImageToCloud(p)));
      const notes = [...this.data.formData.notes];
      if (this.data.noteText.trim()) notes.push({
        type: 'text',
        content: this.data.noteText.trim()
      });
      noteImgIDs.forEach(fid => notes.push({
        type: 'image',
        content: fid
      }));

      /* 4. 组装数据 */
      const payload = {
        categoryId: this.data.categoryId,
        categoryName: this.data.categoryName,
        subcategoryId,
        subcategoryName,
        image: fileID,
        ...this.data.formData,
        notes,
        updatedAt: new Date(),
      };

      /* 5. 写库 */
      if (this.data.isEditMode) {
        await db.collection('clothes').doc(this.data.id).update({
          data: payload
        });
      } else {
        payload.createdAt = new Date();
        await db.collection('clothes').add({
          data: payload
        });
        // 更新分类计数
        const {
          data: cat
        } = await db.collection('categories').doc(this.data.categoryId).get();
        if (cat) {
          await db.collection('categories').doc(this.data.categoryId).update({
            data: {
              count: (cat.count || 0) + 1,
              updateTime: db.serverDate()
            },
          });
        }
      }

      wx.showToast({
        title: this.data.isEditMode ? '已更新' : '保存成功',
        icon: 'success'
      });
      setTimeout(() => wx.navigateBack(), 1200);
    } catch (e) {
      console.error('submitItem error', e);
      wx.showToast({
        title: '保存失败，请重试',
        icon: 'none'
      });
    } finally {
      wx.hideLoading();
    }
  },

  /* ------------------------- 云函数 --------------------------- */
  /** 上传图片 */
  uploadImageToCloud(filePath) {
    return new Promise((resolve, reject) => {
      const ext = filePath.match(/\.\w+$/)?.[0] || '.png';
      const cloudPath = `clothes/${Date.now()}_${Math.random().toString(36).slice(2)}${ext}`;
      wx.cloud.uploadFile({
        cloudPath,
        filePath,
        success: ({
          fileID
        }) => resolve(fileID),
        fail: reject,
      });
    });
  },

  /** 确保存在“未分类”子分类并返回其 id */
  async ensureDefaultSubcategory(categoryId) {
    const {
      data
    } = await db.collection('subcategories').where({
      parentId: categoryId,
      name: '未分类'
    }).get();
    if (data.length) {
      const def = data[0];
      await db.collection('subcategories').doc(def._id).update({
        data: {
          count: (def.count || 0) + 1,
          updateTime: db.serverDate()
        }
      });
      return def._id;
    }
    const {
      data: last
    } = await db.collection('subcategories').where({
      parentId: categoryId
    }).orderBy('order', 'desc').limit(1).get();
    const newOrder = last[0]?.order + 1 || 0;
    const {
      _id
    } = await db.collection('subcategories').add({
      data: {
        name: '未分类',
        parentId: categoryId,
        count: 1,
        order: newOrder,
        createTime: db.serverDate(),
        updateTime: db.serverDate()
      },
    });
    return _id;
  },

  /* ------------------------- 图片 / 备注 / 颜色 等 UI 逻辑（保持原函数名） --------------------------- */
  preventTouchMove() {
    return false;
  },

  chooseImage() {
    /* 保留原实现，可按需优化 */ },

  navigateTo(e) {
    /* 保留原实现 */ },

  showTextInputDialog(field, title, placeholder, type = 'text') {
    /* 原实现 */ },

  showCategorySelector() {
    /* 原实现 */ },
  showSubcategorySelector() {
    /* 原实现 */ },

  showSeasonSelector() {
    /* 原实现 */ },

  showColorDialog() {
    /* 原实现 */ },
  selectColor(e) {
    /* 原实现 */ },
  inputCustomColor(e) {
    /* 原实现 */ },
  confirmColorSelection() {
    /* 原实现 */ },
  cancelColorSelection() {
    this.setData({
      showColorPicker: false
    });
  },

  showDatePickerModal() {
    /* 原实现 */ },
  bindDateChange(e) {
    this.setData({
      currentDate: e.detail.value
    });
  },
  confirmDateSelection() {
    this.setData({
      'formData.purchaseDate': this.data.currentDate,
      showDatePicker: false
    });
  },
  cancelDateSelection() {
    this.setData({
      showDatePicker: false
    });
  },

  addNote() {
    this.setData({
      showNoteInput: true,
      noteText: ''
    });
  },
  inputNoteText(e) {
    this.setData({
      noteText: e.detail.value
    });
  },
  addNoteImage() {
    /* 原实现 */ },
  deleteNoteImage(e) {
    /* 原实现 */ },
  saveNote() {
    /* 原实现 */ },
  cancelNote() {
    this.setData({
      showNoteInput: false,
      noteText: '',
      noteImages: []
    });
  },

  goBack() {
    wx.showModal({
      title: '提示',
      content: '确定要放弃当前编辑吗？',
      success: ({
        confirm
      }) => confirm && wx.navigateBack(),
    });
  },
});