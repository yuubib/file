Page({
  data: {
    categories: [],
    subcategories: {},
    randomResults: [],
    showResults: false,
    isGenerating: false,
    resultsCount: 5, // Number of random combinations to generate
    
    // 多筛选器相关数据
    filters: [
      {
        id: 1, // 每个筛选器的唯一ID
        selectedCategory: '全部',
        selectedSubcategory: '',
        filteredSubcategories: []
      }
    ],
    nextFilterId: 2, // 下一个筛选器的ID
    selectedSubcategoryIds: [] // 存储用于生成搭配的子分类ID
  },

  // ===== 生命周期函数 =====

  onLoad: function(options) {
    // Load categories and subcategories
    this.loadCategories();
  },

  onShow: function() {
    // Refresh data when page is shown
    if (this.data.categories.length === 0) {
      this.loadCategories();
    }
  },

  // ===== 分类加载功能 =====

  // 从云数据库加载分类
  loadCategories: async function() {
    wx.showLoading({
      title: '加载中...',
    });

    try {
      const db = wx.cloud.database();
      const { data: categories } = await db.collection('categories')
        .orderBy('order', 'asc')
        .get();
      
      this.setData({ categories });
      
      // 为每个分类加载子分类
      for (const category of categories) {
        await this.loadSubcategories(category._id);
      }
      
      // 更新所有筛选器的子分类列表
      this.updateAllFilteredSubcategories();
      
      wx.hideLoading();
    } catch (error) {
      wx.hideLoading();
      
      wx.showToast({
        title: '加载分类失败',
        icon: 'none'
      });
    }
  },

  // 加载特定分类的子分类
  loadSubcategories: async function(categoryId) {
    try {
      const db = wx.cloud.database();
      const { data: subcategories } = await db.collection('subcategories')
        .where({ parentId: categoryId })
        .orderBy('order', 'asc')
        .get();
      
      // 更新子分类对象
      const subcategoriesData = { ...this.data.subcategories };
      subcategoriesData[categoryId] = subcategories;
      
      this.setData({ subcategories: subcategoriesData });
    } catch (error) {
      // 子分类加载失败，但不影响整体功能，故仅记录错误
      wx.showToast({
        title: '加载子分类失败',
        icon: 'none'
      });
    }
  },

  // ===== 筛选器操作功能 =====

  // 选择一级分类进行过滤
  selectFilterCategory: function(e) {
    const category = e.currentTarget.dataset.category;
    const filterId = parseInt(e.currentTarget.dataset.filterid);
    
    // 更新特定筛选器的选择
    const filters = [...this.data.filters];
    const filterIndex = filters.findIndex(f => f.id === filterId);
    
    if (filterIndex !== -1) {
      filters[filterIndex].selectedCategory = category;
      filters[filterIndex].selectedSubcategory = ''; // 重置子分类选择
      
      this.setData({ filters });
      
      // 更新该筛选器的子分类列表
      this.updateFilteredSubcategories(filterId);
    }
  },
  
  // 更新特定筛选器的子分类列表
  updateFilteredSubcategories: function(filterId) {
    const { subcategories, categories } = this.data;
    const filters = [...this.data.filters];
    const filterIndex = filters.findIndex(f => f.id === filterId);
    
    if (filterIndex === -1) return;
    
    const selectedCategory = filters[filterIndex].selectedCategory;
    let filteredSubcategories = [];
    
    // 如果选择的是"全部"，则显示所有二级分类
    if (selectedCategory === '全部') {
      // 合并所有分类的子分类
      categories.forEach(category => {
        if (subcategories[category._id] && subcategories[category._id].length > 0) {
          filteredSubcategories = filteredSubcategories.concat(subcategories[category._id]);
        }
      });
    } else {
      // 找到对应的分类ID
      const category = categories.find(c => c.name === selectedCategory);
      
      if (category && subcategories[category._id]) {
        // 过滤对应分类ID的子分类
        filteredSubcategories = subcategories[category._id];
      }
    }
    
    filters[filterIndex].filteredSubcategories = filteredSubcategories;
    this.setData({ filters });
  },
  
  // 更新所有筛选器的子分类列表
  updateAllFilteredSubcategories: function() {
    const filters = this.data.filters;
    
    for (const filter of filters) {
      this.updateFilteredSubcategories(filter.id);
    }
  },
  
  // 选择二级分类进行过滤
  selectFilterSubcategory: function(e) {
    const subcategoryId = e.currentTarget.dataset.subcategory;
    const filterId = parseInt(e.currentTarget.dataset.filterid);
    
    // 更新特定筛选器的选择
    const filters = [...this.data.filters];
    const filterIndex = filters.findIndex(f => f.id === filterId);
    
    if (filterIndex !== -1) {
      filters[filterIndex].selectedSubcategory = subcategoryId;
      this.setData({ filters });
    }
  },
  
  // 添加新的筛选器
  addFilter: function() {
    const { filters, nextFilterId } = this.data;
    
    // 最多允许5个筛选器
    if (filters.length >= 5) {
      wx.showToast({
        title: '最多只能添加5个筛选器',
        icon: 'none'
      });
      return;
    }
    
    // 添加新筛选器
    const newFilter = {
      id: nextFilterId,
      selectedCategory: '全部',
      selectedSubcategory: '',
      filteredSubcategories: []
    };
    
    this.setData({
      filters: [...filters, newFilter],
      nextFilterId: nextFilterId + 1
    });
    
    // 更新新筛选器的子分类列表
    this.updateFilteredSubcategories(nextFilterId);
  },
  
  // 删除筛选器
  removeFilter: function(e) {
    const filterId = parseInt(e.currentTarget.dataset.filterid);
    const filters = this.data.filters.filter(f => f.id !== filterId);
    
    // 至少保留一个筛选器
    if (filters.length === 0) {
      wx.showToast({
        title: '至少需要保留一个筛选器',
        icon: 'none'
      });
      return;
    }
    
    this.setData({ filters });
  },
  
  // ===== 数据查询功能 =====
  
  // 获取指定分类下的所有衣物
  getItemsByCategory: async function(categoryName, subcategoryId = '') {
    const db = wx.cloud.database();
    const _ = db.command;
    
    try {
      // 如果是"全部"类别，获取所有衣物
      if (categoryName === '全部') {
        const { data: allItems } = await db.collection('clothes').get();
        return allItems;
      }
      
      // 找到指定分类的ID
      const category = this.data.categories.find(c => c.name === categoryName);
      
      if (!category) {
        return [];
      }
      
      // 如果有选择子分类，只获取该子分类的衣物
      if (subcategoryId) {
        const { data: items } = await db.collection('clothes')
          .where({ subcategoryId: subcategoryId })
          .get();
        return items;
      }
      
      // 获取该分类下所有子分类ID
      const subcategoryIds = this.data.subcategories[category._id]
        ? this.data.subcategories[category._id].map(s => s._id)
        : [];
      
      // 如果没有子分类，返回空数组
      if (subcategoryIds.length === 0) {
        return [];
      }
      
      // 获取这些子分类下的所有衣物
      const { data: items } = await db.collection('clothes')
        .where({
          subcategoryId: _.in(subcategoryIds)
        })
        .get();
      
      return items;
    } catch (error) {
      wx.showToast({
        title: '获取衣物失败',
        icon: 'none'
      });
      return [];
    }
  },
  
  // ===== 搭配生成功能 =====
  
  // 生成随机搭配
  generateRandomOutfit: async function() {
    // 检查是否有选择有效的分类
    const hasValidSelection = this.data.filters.some(filter => 
      filter.selectedCategory !== '全部'
    );
    
    if (!hasValidSelection) {
      wx.showToast({
        title: '请至少选择一个分类',
        icon: 'none'
      });
      return;
    }

    // 显示加载提示
    this.setData({ isGenerating: true, showResults: false });
    wx.showLoading({
      title: '生成搭配中...',
    });

    try {
      // 存储每个筛选器对应的物品
      const filterItems = {};
      
      // 获取每个筛选器对应的衣物
      for (const filter of this.data.filters) {
        // 只有当选择了分类时才处理该筛选器
        if (filter.selectedCategory === '全部') {
          continue; // 跳过未选择分类的筛选器
        }
        
        const items = await this.getItemsByCategory(
          filter.selectedCategory, 
          filter.selectedSubcategory
        );
        
        if (items && items.length > 0) {
          filterItems[filter.id] = items;
        }
      }
      
      // 如果没有找到任何衣物，显示提示并返回
      if (Object.keys(filterItems).length === 0) {
        wx.hideLoading();
        this.setData({ isGenerating: false });
        wx.showToast({
          title: '未找到可用的衣物',
          icon: 'none'
        });
        return;
      }
      
      // 生成结果数组
      const results = [];
      const maxAttempts = 50;
      const targetCount = this.data.resultsCount;
      const filterIds = Object.keys(filterItems);
      
      // 生成指定数量的随机搭配
      for (let i = 0; i < maxAttempts && results.length < targetCount; i++) {
        const outfit = {};
        
        // 为每个筛选器随机选择一件衣物
        for (const filterId of filterIds) {
          const items = filterItems[filterId];
          const randomIndex = Math.floor(Math.random() * items.length);
          
          // 添加子分类ID和衣物信息到搭配中
          const item = items[randomIndex];
          outfit[item.subcategoryId] = {
            ...item,
            subcategoryName: this.getSubcategoryNameById(item.subcategoryId)
          };
        }
        
        // 检查是否为唯一搭配
        const isUnique = !this.isDuplicateOutfit(results, outfit);
        
        if (isUnique) {
          results.push(outfit);
        }
      }
      
      // 获取所有用于展示的子分类ID
      const displaySubcategoryIds = [];
      results.forEach(outfit => {
        Object.keys(outfit).forEach(subcategoryId => {
          if (!displaySubcategoryIds.includes(subcategoryId)) {
            displaySubcategoryIds.push(subcategoryId);
          }
        });
      });
      
      this.setData({
        randomResults: results,
        showResults: true,
        isGenerating: false,
        selectedSubcategoryIds: displaySubcategoryIds
      });
      
      wx.hideLoading();
      
      if (results.length === 0) {
        wx.showToast({
          title: '未找到可用搭配',
          icon: 'none'
        });
      }
    } catch (error) {
      wx.hideLoading();
      this.setData({ isGenerating: false });
      
      wx.showToast({
        title: '生成搭配失败',
        icon: 'none'
      });
    }
  },
  
  // ===== 辅助功能 =====
  
  // 检查搭配是否重复
  isDuplicateOutfit: function(existingOutfits, newOutfit) {
    for (const outfit of existingOutfits) {
      let isDuplicate = true;
      
      // 检查所有子分类
      for (const subcategoryId in newOutfit) {
        // 如果现有搭配中没有该子分类，或者衣物ID不同，则不是重复的
        if (!outfit[subcategoryId] || outfit[subcategoryId]._id !== newOutfit[subcategoryId]._id) {
          isDuplicate = false;
          break;
        }
      }
      
      if (isDuplicate) return true;
    }
    
    return false;
  },
  
  // 根据子分类ID获取子分类名称
  getSubcategoryNameById: function(subcategoryId) {
    for (const categoryId in this.data.subcategories) {
      const subcategories = this.data.subcategories[categoryId];
      const subcategory = subcategories.find(sub => sub._id === subcategoryId);
      if (subcategory) {
        return subcategory.name;
      }
    }
    return '单品';
  },
  
  // 根据子分类ID获取子分类对象
  getSubcategoryById: function(subcategoryId) {
    for (const categoryId in this.data.subcategories) {
      const subcategories = this.data.subcategories[categoryId];
      const subcategory = subcategories.find(sub => sub._id === subcategoryId);
      if (subcategory) {
        return subcategory;
      }
    }
    return null;
  },
  
  // 根据当前分类获取兼容的分类
  getCompatibleCategories: function(categoryName) {
    // 根据不同的分类，返回合适的搭配分类
    switch (categoryName) {
      case '上装':
        return ['下装', '鞋子', '配饰'];
      case '下装':
        return ['上装', '鞋子', '配饰'];
      case '鞋子':
        return ['上装', '下装', '配饰'];
      case '包包':
        return ['上装', '下装', '鞋子'];
      case '配饰':
        return ['上装', '下装', '鞋子'];
      default:
        return ['上装', '下装', '鞋子', '配饰'].filter(name => name !== categoryName);
    }
  },

  // 清除所有选择
  clearSelections: function() {
    // 重置所有筛选器
    const resetFilters = [{
      id: 1,
      selectedCategory: '全部',
      selectedSubcategory: '',
      filteredSubcategories: []
    }];
    
    this.setData({
      filters: resetFilters,
      nextFilterId: 2,
      randomResults: [],
      showResults: false,
      selectedSubcategoryIds: []
    });
    
    // 更新筛选器的子分类列表
    this.updateFilteredSubcategories(1);
  },

  // 保存搭配
  saveOutfit: function(e) {
    const { resultIndex } = e.currentTarget.dataset;
    const outfit = this.data.randomResults[resultIndex];
    
    if (!outfit) return;
    
    // 显示开发中提示
    this.showDevelopingFeature('保存搭配');
  },
  
  // 显示功能开发中提示
  showDevelopingFeature: function(featureName) {
    wx.showToast({
      title: `${featureName}功能开发中`,
      icon: 'none'
    });
  }
});