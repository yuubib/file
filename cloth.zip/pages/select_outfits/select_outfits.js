// pages/select_outfits/select_outfits.js
Page({
  data: {
    outfits: [],
    selectedOutfits: [],
    searchQuery: '',
    loading: true
  },
  
  //=================== 生命周期函数 ===================
  
  onLoad: function(options) {
    // 解析已选择的搭配（如果有）
    if (options.selectedOutfits) {
      try {
        const selectedOutfits = JSON.parse(options.selectedOutfits);
        this.setData({
          selectedOutfits: selectedOutfits
        });
      } catch (e) {
        wx.showToast({
          title: '解析已选择搭配失败',
          icon: 'none'
        });
      }
    }
    
    // 加载所有搭配
    this.loadOutfits();
  },
  
  //=================== 数据加载函数 ===================
  
  // 从云数据库加载搭配
  loadOutfits: function() {
    this.setData({ loading: true });
    
    const db = wx.cloud.database();
    db.collection('outfits')
      .get()
      .then(res => {
        this.setData({
          outfits: res.data,
          loading: false
        });
      })
      .catch(err => {
        this.setData({ loading: false });
        wx.showToast({
          title: '加载搭配失败',
          icon: 'none'
        });
      });
  },
  
  //=================== 搭配选择函数 ===================
  
  // 切换搭配的选择状态
  toggleOutfitSelection: function(e) {
    const outfitId = e.currentTarget.dataset.id;
    const outfit = this.data.outfits.find(o => o._id === outfitId);
    
    if (!outfit) return;
    
    // 检查搭配是否已经被选择
    const index = this.data.selectedOutfits.findIndex(o => o.id === outfitId);
    
    if (index > -1) {
      // 搭配已被选择，移除它
      const newSelectedOutfits = [...this.data.selectedOutfits];
      newSelectedOutfits.splice(index, 1);
      this.setData({
        selectedOutfits: newSelectedOutfits
      });
    } else {
      // 搭配未被选择，添加它
      const newSelectedOutfits = [...this.data.selectedOutfits];
      newSelectedOutfits.push({
        id: outfit._id,
        name: outfit.name || '搭配',
        image: outfit.image || ''
      });
      this.setData({
        selectedOutfits: newSelectedOutfits
      });
    }
  },
  
  // 检查搭配是否已被选择
  isOutfitSelected: function(outfitId) {
    return this.data.selectedOutfits.some(outfit => outfit.id === outfitId);
  },
  
  //=================== 搜索函数 ===================
  
  // 处理搜索输入
  onSearchInput: function(e) {
    this.setData({
      searchQuery: e.detail.value
    });
  },
  
  //=================== 操作函数 ===================
  
  // 确认选择并返回上一页
  confirmSelection: function() {
    // 将选中的搭配传回添加灵感页面
    const app = getApp();
    if (!app.globalData) {
      app.globalData = {};
    }
    
    app.globalData.selectedRelatedOutfits = this.data.selectedOutfits;
    wx.navigateBack();
  },
  
  // 取消并返回上一页
  cancelSelection: function() {
    wx.navigateBack();
  }
}); 