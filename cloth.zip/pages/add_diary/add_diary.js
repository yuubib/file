const app = getApp();
const db = wx.cloud.database();
const diaryCollection = db.collection('diary');

Page({
  data: {
    date: '',
    year: '',
    month: '',
    day: '',
    weather: '',
    content: '',
    images: [],
    showDatePicker: false,
    showWeatherPicker: false,
    weatherOptions: ['晴', '多云', '阴', '小雨', '中雨', '大雨', '暴雨', '雪', '雾', '霾', '风', '沙尘'],
    selectedWeather: '',
    years: [],
    months: [],
    days: [],
    datePickerValue: [0, 0, 0],
    isEdit: false,
    diaryId: '',
    cloudImages: false
  },

  onLoad: function (options) {
    if (options.isEdit && options.id) {
      this.setData({
        isEdit: true,
        diaryId: options.id
      });
      
      this.loadDiaryData(options.id);
    }
    
    if (options.date) {
      const date = new Date(options.date);
      this.setData({
        date: options.date,
        year: date.getFullYear(),
        month: this.formatNumber(date.getMonth() + 1),
        day: this.formatNumber(date.getDate())
      });
    } else {
      const today = new Date();
      this.setData({
        date: today.toISOString().split('T')[0],
        year: today.getFullYear(),
        month: this.formatNumber(today.getMonth() + 1),
        day: this.formatNumber(today.getDate())
      });
    }
    this.initDatePickerData();
  },

  loadDiaryData: function(diaryId) {
    wx.showLoading({
      title: '加载中...',
    });
    
    db.collection('diary').doc(diaryId).get()
      .then(res => {
        const diary = res.data;
        
        this.setData({
          date: diary.date,
          year: new Date(diary.date).getFullYear(),
          month: this.formatNumber(new Date(diary.date).getMonth() + 1),
          day: this.formatNumber(new Date(diary.date).getDate()),
          weather: diary.weather || '',
          content: diary.content || '',
          images: diary.images || [],
          cloudImages: true
        });
        
        this.initDatePickerData();
        
        wx.hideLoading();
      })
      .catch(err => {
        console.error('加载日记数据失败:', err);
        wx.hideLoading();
        wx.showToast({
          title: '加载日记失败',
          icon: 'none'
        });
      });
  },

  initDatePickerData: function() {
    const currentYear = new Date().getFullYear();
    const years = [];
    const months = [];
    const days = [];
    
    for (let i = currentYear - 5; i <= currentYear + 5; i++) {
      years.push(i);
    }
    
    for (let i = 1; i <= 12; i++) {
      months.push(this.formatNumber(i));
    }
    
    const daysInMonth = new Date(this.data.year, this.data.month, 0).getDate();
    for (let i = 1; i <= daysInMonth; i++) {
      days.push(this.formatNumber(i));
    }
    
    const yearIndex = years.findIndex(y => y === parseInt(this.data.year));
    const monthIndex = months.findIndex(m => m === this.data.month);
    const dayIndex = days.findIndex(d => d === this.data.day);
    
    this.setData({
      years,
      months,
      days,
      datePickerValue: [
        yearIndex > -1 ? yearIndex : 0,
        monthIndex > -1 ? monthIndex : 0,
        dayIndex > -1 ? dayIndex : 0
      ]
    });
  },

  formatNumber: function (n) {
    n = n.toString();
    return n[1] ? n : '0' + n;
  },

  inputContent: function (e) {
    this.setData({
      content: e.detail.value
    });
  },

  chooseImage: function () {
    wx.chooseImage({
      count: 9 - this.data.images.length,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        if (this.data.cloudImages) {
          this.setData({
            cloudImages: false
          });
        }
        
        this.setData({
          images: this.data.images.concat(res.tempFilePaths)
        });
      }
    });
  },

  deleteImage: function (e) {
    const index = e.currentTarget.dataset.index;
    const images = this.data.images;
    images.splice(index, 1);
    
    const cloudImages = (this.data.cloudImages && images.length === 0) ? false : this.data.cloudImages;
    
    this.setData({ 
      images,
      cloudImages
    });
  },

  previewImage: function(e) {
    let urls = this.data.images;
    
    if (this.data.isEdit && this.data.tempCloudImages && this.data.tempCloudImages.length > 0) {
      urls = [...urls, ...this.data.tempCloudImages];
    }
    
    wx.previewImage({
      current: e.currentTarget.dataset.src,
      urls: urls
    });
  },

  showDatePicker: function() {
    this.setData({ showDatePicker: true });
  },

  hideDatePicker: function() {
    this.setData({ showDatePicker: false });
  },

  stopPropagation: function() {
    return;
  },

  onDatePickerChange: function(e) {
    const val = e.detail.value;
    
    if (val[0] !== this.data.datePickerValue[0] || val[1] !== this.data.datePickerValue[1]) {
      const year = this.data.years[val[0]];
      const month = this.data.months[val[1]];
      const daysInMonth = new Date(year, month, 0).getDate();
      
      const days = [];
      for (let i = 1; i <= daysInMonth; i++) {
        days.push(this.formatNumber(i));
      }
      
      let dayIndex = val[2];
      if (dayIndex >= days.length) {
        dayIndex = days.length - 1;
      }
      
      this.setData({
        days,
        datePickerValue: [val[0], val[1], dayIndex]
      });
    } else {
      this.setData({ datePickerValue: val });
    }
  },

  confirmDate: function() {
    const year = this.data.years[this.data.datePickerValue[0]];
    const month = this.data.months[this.data.datePickerValue[1]];
    const day = this.data.days[this.data.datePickerValue[2]];
    
    this.setData({
      year: year.toString(),
      month,
      day,
      date: `${year}-${month}-${day}`,
      showDatePicker: false
    });
  },

  showWeatherPicker: function() {
    this.setData({
      showWeatherPicker: true,
      selectedWeather: this.data.weather
    });
  },

  hideWeatherPicker: function() {
    this.setData({ showWeatherPicker: false });
  },

  selectWeather: function(e) {
    this.setData({
      selectedWeather: e.currentTarget.dataset.weather
    });
  },

  confirmWeather: function() {
    this.setData({
      weather: this.data.selectedWeather,
      showWeatherPicker: false
    });
  },

  saveDiary: async function () {
    if (!this.data.content.trim()) {
      wx.showToast({
        title: '请输入日记内容',
        icon: 'none'
      });
      return;
    }
    
    wx.showLoading({ title: '保存中...' });
    
    try {
      let cloudImages = [];
      
      if (this.data.isEdit && this.data.cloudImages) {
        cloudImages = this.data.images;
      } else {
        for (let i = 0; i < this.data.images.length; i++) {
          if (this.data.images[i].startsWith('http') || this.data.images[i].startsWith('cloud://')) {
            cloudImages.push(this.data.images[i]);
          } else {
            const cloudPath = `diary/${Date.now()}_${i}.jpg`;
            const result = await wx.cloud.uploadFile({
              cloudPath,
              filePath: this.data.images[i]
            });
            cloudImages.push(result.fileID);
          }
        }
      }
      
      const diaryData = {
        userId: app.globalData.openid || 'temp_user',
        date: this.data.date,
        time: new Date().toTimeString().substr(0, 5),
        weather: this.data.weather,
        content: this.data.content,
        images: cloudImages,
        updatedAt: db.serverDate()
      };
      
      let res;
      
      if (this.data.isEdit) {
        res = await diaryCollection.doc(this.data.diaryId).update({
          data: diaryData
        });
      } else {
        diaryData.createdAt = db.serverDate();
        res = await diaryCollection.add({ data: diaryData });
      }
      
      wx.hideLoading();
      
      if (this.data.isEdit ? res.stats.updated > 0 : res._id) {
        wx.showToast({
          title: this.data.isEdit ? '更新成功' : '保存成功',
          icon: 'success'
        });
        
        setTimeout(() => {
          const pages = getCurrentPages();
          const prevPage = pages[pages.length - 2];
          
          if (prevPage && prevPage.route === 'pages/calendar/calendar') {
            prevPage.loadRecords();
          }
          
          wx.navigateBack();
        }, 1500);
      } else {
        throw new Error(this.data.isEdit ? '更新失败' : '保存失败');
      }
    } catch (error) {
      console.error('保存/更新日记失败:', error);
      wx.hideLoading();
      wx.showToast({
        title: this.data.isEdit ? '更新失败，请重试' : '保存失败，请重试',
        icon: 'none'
      });
    }
  }
}); 