// pages/home/index.js
/**
 * 首页 – 搭配概览
 * 作者：你
 * 创建日期：2025-04-10
 * 功能：展示天气、热门标签、轮播图与分类入口
 */
const app = getApp();
const CAIYUN_TOKEN = 'hLe2JRO94lgWAfoA'; // 彩云天气 Token
const QQMAP_KEY = 'TJGBZ-BKKL4-4BLUQ-KNWZR-XPHW3-2OBYY'; // 腾讯位置服务 Key（需替换）
const JUHE_KEY = 'YOUR_JUHE_KEY'; // 替换为你的聚合数据 API Key
const skyconMap = {
  CLEAR_DAY: '../../images/weather/clear_day.png',
  CLEAR_NIGHT: '../../images/weather/clear_night.png',
  PARTLY_CLOUDY_DAY: '../../images/weather/partly_cloudy_day.png',
  PARTLY_CLOUDY_NIGHT: '../../images/weather/partly_cloudy_night.png',
  CLOUDY: '../../images/weather/cloudy.png',
  LIGHT_HAZE: '../../images/weather/haze.png',
  RAIN: '../../images/weather/rain.png',
  SNOW: '../../images/weather/snow.png'
};
const CAT_ICONS = [
  'cloud://cloud1-7g4mn88sf5a1e031.636c-cloud1-7g4mn88sf5a1e031-1349107995/image/1.png',
  'cloud://cloud1-7g4mn88sf5a1e031.636c-cloud1-7g4mn88sf5a1e031-1349107995/image/2.png',
  'cloud://cloud1-7g4mn88sf5a1e031.636c-cloud1-7g4mn88sf5a1e031-1349107995/image/3.png',
  'cloud://cloud1-7g4mn88sf5a1e031.636c-cloud1-7g4mn88sf5a1e031-1349107995/image/4.png'
];
Page({
  data: {
    weather: {
      city: '加载中',
      tempMin: '--',
      tempMax: '--',
      desc: '',
      pm25: '--',
      icon: ''
    },
    calendar: {
      date: '', // 格式化的公历日期，例如 "4月11日"
      weekday: '', // 星期几，如 "星期五"
    },
    wardrobeStats: {
      items: 0,
      outfits: 0,
      calendar: 0,
      inspiration: 0,
    },
    hotTags: [],
    banners: [],
    /** 用户可选择的搭配大类 */
    outCategories: [],
    categories: []
  },

  /** 生命周期函数—页面加载 */
  async onLoad() {
    //this.getHotTags();
    this.getBanners();
    this.getCategories();
    this.getCalendarInfo();
    this.loadWardrobeStats();
    wx.getLocation({
      type: 'wgs84',
      success: async loc => {
        await this.fetchWeather(loc.latitude, loc.longitude);
      },
      fail: async () => {
        // 若用户拒绝定位，使用默认坐标（德令哈）
        console.error('deny location')
        await this.fetchWeather(39.2072, 101.6656);
      }
    });
  },
  onShow() {
    this.loadWardrobeStats(); // 与天气卡片数据一起刷新
  },
  async fetchWeather(lat, lon) {
    const realtimeUrl = `https://api.caiyunapp.com/v2.6/${CAIYUN_TOKEN}/${lon},${lat}/realtime`;
    const dailyUrl = `https://api.caiyunapp.com/v2.6/${CAIYUN_TOKEN}/${lon},${lat}/daily?dailysteps=1`;

    try {
      const [realtimeRes, dailyRes] = await Promise.all([
        this.wxRequest(realtimeUrl),
        this.wxRequest(dailyUrl)
      ]);

      const {
        temperature,
        skycon,
        air_quality
      } = realtimeRes.result.realtime;
      const {
        temperature: tempRange,
        skycon: skyArr
      } = dailyRes.result.daily;

      // 取当天最高最低温
      const tempMin = tempRange[0].min.toFixed(0);
      const tempMax = tempRange[0].max.toFixed(0);

      // 天气描述
      const desc = skyArr[0].value === 'CLEAR_DAY' ? '晴' : '多云'; // 简易示例，可自行完善映射

      // 获取城市名
      let city = '当前位置';
      console.error('location', city)
      try {
        const geoUrl = `https://apis.map.qq.com/ws/geocoder/v1/?location=${lat},${lon}&type=3&key=${QQMAP_KEY}`;
        const geoRes = await this.wxRequest(geoUrl);
        city = geoRes.result.address_component.city;
      } catch (_) {
        console.error('location gg', city)
      }

      this.setData({
        weather: {
          city,
          tempMin,
          tempMax,
          desc,
          pm25: air_quality.pm25,
          icon: skyconMap[skycon] || skyconMap.CLOUDY
        }
      });
    } catch (e) {
      console.error('天气加载失败', e);
    }
  },

  /** Promise 封装 wx.request */
  wxRequest(url) {
    return new Promise((resolve, reject) => {
      wx.request({
        url,
        success: res => resolve(res.data),
        fail: reject
      });
    });
  },
  /** 获取天气信息（彩云天气 API，无云函数） */
  getWeather() {
    wx.request({
      url: WEATHER_URL,
      success: ({
        data
      }) => {
        if (data.status === 'ok') {
          const temp = data.result.realtime.temperature;
          this.setData({
            weather: {
              city: '德令哈', // 固定城市名，可根据需要改为定位结果
              temp: temp.toFixed(0)
            }
          });
        }
      },
      fail: (e) => {
        console.error('天气获取失败', e);
      }
    });
  },

  /** 获取热门标签 */
  async getHotTags() {
    try {
      const res = await app.globalData.db.collection('tags')
        .orderBy('count', 'desc')
        .limit(6)
        .get();
      this.setData({
        hotTags: res.data.map(v => v.name)
      });
    } catch (e) {
      console.error('标签获取失败', e);
    }
  },

  /** 获取轮播图 */
  async getBanners() {
    try {
      const res = await app.globalData.db.collection('banners').get();
      this.setData({
        banners: res.data.map(v => v.img)
      });
    } catch (e) {
      console.error('Banner 获取失败', e);
    }
  },

  /** 获取分类 */
  async getCategories() {
    try {
      const db = wx.cloud.database();
      const {
        data: rawCats
      } = await db.collection('categories')
        .orderBy('order', 'asc')
        .get();
      const categories = rawCats
        .map((c, idx) => ({
          ...c,
          icon: CAT_ICONS[idx % CAT_ICONS.length]
        }))
        .slice(0, 4); // ← 只取前 4 个

      this.setData({
        categories
      });
    } catch (e) {
      console.error('分类获取失败', e);
    }
  },

  /** 获取搭配大类（out_categories） */
  async getOutCategories() {
    try {
      const res = await app.globalData.db.collection('outfit_categories')
        .orderBy('order', 'asc')
        .get();
      this.setData({
        outCategories: res.data
      });
    } catch (e) {
      if (e.errCode !== -502005) console.error('outfit_categories 获取失败', e);
    }
  },

  /** 交互事件 */
  onSearch() {
    wx.navigateTo({
      url: '/pages/search/index'
    });
  },
  onCalendar() {
    wx.navigateTo({
      url: '/pages/calendar/index'
    });
  },
  async onEntry() {
    // 若尚未加载搭配分类，则先从 out_categories 集合拉取
    if (!this.data.outCategories.length) {
      await this.getOutCategories();
    }

    // 若依旧为空，提示用户
    if (!this.data.outCategories.length) {
      wx.showToast({
        title: '暂无可用分类',
        icon: 'none'
      });
      return;
    }

    const names = this.data.outCategories.map(c => c.name);

    wx.showActionSheet({
      itemList: names,
      success: res => {
        const idx = res.tapIndex;
        const categoryId = this.data.outCategories[idx]._id;
        wx.navigateTo({
          url: `/pages/collage/collage?categoryId=${categoryId}`
        });
      }
    });
  },
  onTagTap(e) {
    const tag = e.currentTarget.dataset.item;
    wx.navigateTo({
      url: `/pages/search/index?tag=${tag}`
    });
  },
  onCategoryTap(e) {
    const categoryId = e.currentTarget.dataset.category;
    const category = this.data.categories.find(item => item._id === categoryId);
    const categoryName = category ? category.name : '';
    wx.navigateTo({
      url: `/pages/subcategory_list/subcategory_list?parentId=${categoryId}&parentName=${encodeURIComponent(categoryName)}`
    });
  },
  onWeatherTap() {
    wx.navigateTo({
      url: '/pages/calendar/calendar'
    });
  },
  getCalendarInfo() {
    const d = new Date();
    // 获取月份和日期
    const month = d.getMonth() + 1;
    const date = d.getDate();
    // 星期（0：星期日，1：星期一…）
    const weekDays = ['日', '一', '二', '三', '四', '五', '六'];
    const weekday = '星期' + weekDays[d.getDay()];

    // 设置格式化后的日期，如 "5月18日"
    const formattedDate = `${month}月${date}日`;

    this.setData({
      calendar: {
        date: formattedDate,
        weekday
      }
    });
  },
  loadWardrobeStats() {
    wx.showLoading({
      title: '加载中...',
      mask: true
    });

    const db = wx.cloud.database();
    const promises = [
      db.collection('clothes').count(), // 单品
      db.collection('collages').count(), // 搭配
    ];

    Promise.all(promises)
      .then(([clothesRes, collagesRes, calendarRes, inspirationsRes]) => {
        this.setData({
          'wardrobeStats.items': clothesRes.total || 0,
          'wardrobeStats.outfits': collagesRes.total || 0,
        });
        wx.hideLoading();
      })
      .catch(err => {
        console.error('获取统计数据失败:', err);

        // —— 本地兜底 —— //
        const clothItems = wx.getStorageSync('clothItems') || [];
        const outfits = wx.getStorageSync('outfits') || [];

        Object.values(inspirations).forEach(arr => {
          if (Array.isArray(arr)) inspirationCount += arr.length;
        });

        this.setData({
          'wardrobeStats.items': clothItems.length,
          'wardrobeStats.outfits': outfits.length,
        });

        wx.hideLoading();
        wx.showToast({
          title: '使用本地统计数据',
          icon: 'none'
        });
      });
  },
});