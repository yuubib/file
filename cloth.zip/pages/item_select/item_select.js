Page({
  data: {
    // 数据源
    items: [], // 所有衣物
    
    // 分类数据
    categories: [], // 从数据库加载的分类
    subcategories: [], // 从数据库加载的子分类
    
    // 过滤和选择状态
    selectedCategory: '全部',
    selectedSubcategory: '',
    filteredSubcategories: [],
    filteredItems: [],
    selectedItems: [], // 已选中的单品
    selectionCount: 0  // 已选中的单品数量
  },

  // 生命周期函数
  onLoad: function() {
    // 加载分类数据
    this.loadCategories();
    
    // 加载衣物数据
    this.loadItems();
  },

  // ===== 数据加载功能 =====
  
  // 加载分类数据
  loadCategories: function() {
    const db = getApp().globalData.db;
    
    // 从云数据库获取所有分类
    db.collection('categories').get().then(res => {
      // 按照顺序排序
      const orderedCategories = res.data.sort((a, b) => a.order - b.order);
      
      this.setData({
        categories: orderedCategories
      });
      
      // 加载子分类
      this.loadSubcategories();
      
    }).catch(err => {
      console.error('获取分类数据失败', err);
      wx.showToast({
        title: '获取分类数据失败',
        icon: 'none'
      });
    });
  },
  
  // 加载子分类数据
  loadSubcategories: function() {
    const db = getApp().globalData.db;
    
    // 从云数据库获取所有子分类
    db.collection('subcategories').get().then(res => {
      // 按照顺序排序
      const orderedSubcategories = res.data.sort((a, b) => a.order - b.order);
      
      this.setData({
        subcategories: orderedSubcategories
      });
      
      // 更新二级分类列表
      this.updateSubcategories();
      
    }).catch(err => {
      console.error('获取子分类数据失败', err);
      wx.showToast({
        title: '获取子分类数据失败',
        icon: 'none'
      });
    });
  },

  // 加载衣物数据
  loadItems: function() {
    const db = getApp().globalData.db;
    
    wx.showLoading({
      title: '加载中...'
    });
    
    // 从云数据库获取所有衣物
    db.collection('clothes').get().then(res => {
      this.setData({
        items: res.data,
        filteredItems: res.data
      });
      wx.hideLoading();
    }).catch(err => {
      console.error('获取衣物数据失败', err);
      wx.hideLoading();
      
      // 如果获取失败，使用本地存储的数据
      const clothItems = wx.getStorageSync('clothItems') || [];
      this.setData({
        items: clothItems,
        filteredItems: clothItems
      });
      
      wx.showToast({
        title: '使用本地数据',
        icon: 'none'
      });
    });
  },

  // ===== 分类筛选功能 =====
  
  // 选择一级分类
  selectCategory: function(e) {
    const category = e.currentTarget.dataset.category;
    
    this.setData({
      selectedCategory: category,
      selectedSubcategory: '' // 重置二级分类选择
    });
    
    // 更新二级分类列表
    this.updateSubcategories();
    
    // 应用筛选
    this.applyFilters();
  },
  
  // 更新二级分类列表
  updateSubcategories: function() {
    const { selectedCategory, subcategories, categories } = this.data;
    let filteredSubcategories = [];
    
    // 如果选择的是"全部"，则显示所有二级分类
    if (selectedCategory === '全部') {
      filteredSubcategories = [...subcategories];
    } else {
      // 找到对应的分类ID
      const category = categories.find(c => c.name === selectedCategory);
      
      if (category) {
        // 过滤对应分类ID的子分类
        filteredSubcategories = subcategories.filter(sub => sub.categoryId === category._id);
      }
    }
    
    this.setData({ filteredSubcategories });
  },
  
  // 选择二级分类
  selectSubcategory: function(e) {
    const subcategoryId = e.currentTarget.dataset.subcategory;
    
    this.setData({
      selectedSubcategory: subcategoryId
    });
    
    // 应用筛选
    this.applyFilters();
  },
  
  // 应用筛选条件
  applyFilters: function() {
    const { items, selectedCategory, selectedSubcategory, categories, subcategories } = this.data;
    let filteredItems = [...items];
    
    // 根据一级分类筛选
    if (selectedCategory !== '全部') {
      // 找到对应的分类
      const category = categories.find(c => c.name === selectedCategory);
      
      if (category) {
        filteredItems = filteredItems.filter(item => 
          item.categoryId === category._id
        );
      }
    }
    
    // 根据二级分类筛选
    if (selectedSubcategory) {
      filteredItems = filteredItems.filter(item => 
        item.subcategoryId === selectedSubcategory
      );
    }
    
    this.setData({ filteredItems });
  },
  
  // ===== 单品选择功能 =====
  
  // 判断某个单品是否被选中
  isItemSelected: function(itemId) {
    return this.data.selectedItems.some(item => item._id === itemId);
  },

  // 选择/取消选择单品
  toggleSelectItem: function(e) {
    const itemId = e.currentTarget.dataset.id;
    const { selectedItems, items } = this.data;
    
    // 检查该项是否已被选中
    const index = selectedItems.findIndex(item => item._id === itemId);
    
    if (index === -1) {
      // 如果未选中，添加到选中列表
      const item = items.find(item => item._id === itemId);
      if (item) {
        const newSelectedItems = [...selectedItems, item];
        this.setData({
          selectedItems: newSelectedItems,
          selectionCount: newSelectedItems.length
        });
      }
    } else {
      // 如果已选中，从选中列表移除
      const newSelectedItems = [...selectedItems];
      newSelectedItems.splice(index, 1);
      this.setData({
        selectedItems: newSelectedItems,
        selectionCount: newSelectedItems.length
      });
    }
  },

  // ===== 操作功能 =====
  
  // 完成选择
  complete: function() {
    const { selectedItems } = this.data;
    
    // 验证至少选择了一个单品
    if (selectedItems.length === 0) {
      wx.showToast({
        title: '请至少选择一个单品',
        icon: 'none'
      });
      return;
    }
    
    // 获取前一页面
    const pages = getCurrentPages();
    const prevPage = pages[pages.length - 2]; // 上一个页面
    
    // 调用上一个页面的方法，传递选中的衣物
    if (prevPage && prevPage.addSelectedClothingItems) {
      prevPage.addSelectedClothingItems(selectedItems);
    }
    
    // 返回上一页
    wx.navigateBack();
  },

  // 取消选择
  cancel: function() {
    wx.navigateBack();
  }
}) 