Page({
  data: {
    formData: {
      title: '',
      tags: '',
      note: '',
      link: '',
      relatedItems: [],
      relatedOutfits: []
    },
    imagePath: '',
    categoryId: null,
    categoryName: '',
    cloud_image_path: '', // 用于存储上传到云存储的图片路径
    isBatch: false,       // 是否是批量导入模式
    batchTotal: 0,        // 批量总数
    batchCurrentIndex: 0  // 当前处理的索引
  },

  onLoad: function(options) {
    // 如果从分类跳转过来，则自动选择分类
    if (options.categoryId) {
      this.setData({
        categoryId: options.categoryId,
        categoryName: options.categoryName || ''
      });
    }

    // 检查是否是批量导入模式
    if (options.isBatch === 'true' && options.batchTotal) {
      this.setData({
        isBatch: true,
        batchTotal: parseInt(options.batchTotal) || 0,
        batchCurrentIndex: 0
      });
    }

    // 如果从相册/相机选择了图片，则从全局数据获取图片路径
    if (options.hasImage === 'true') {
      const app = getApp();
      if (app.globalData && app.globalData.tempInspirationImage) {
        console.log('从globalData获取图片路径:', app.globalData.tempInspirationImage);
        this.setData({
          imagePath: app.globalData.tempInspirationImage
        });
        
        // 如果不是批量模式，使用完毕后清除，避免内存泄漏
        if (!this.data.isBatch) {
          app.globalData.tempInspirationImage = null;
        }
      }
    } 
    // 旧版方式：直接从URL参数获取图片路径（保留兼容性）
    else if (options.imagePath) {
      try {
        const decodedImagePath = decodeURIComponent(options.imagePath);
        console.log('从URL参数获取并解码图片路径:', decodedImagePath);
        this.setData({
          imagePath: decodedImagePath
        });
      } catch (e) {
        console.error('解码图片路径失败:', e);
        this.setData({
          imagePath: options.imagePath
        });
      }
    }

    // 加载分类数据
    this.loadCategories();
  },

  // ... existing code ...

  // 保存灵感
  saveInspiration: async function() {
    if (!this.data.imagePath) {
      wx.showToast({
        title: '请选择图片',
        icon: 'none'
      });
      return;
    }

    // 如果没有选择分类，提示用户选择
    if (!this.data.categoryId) {
      this.showCategorySelector();
      return;
    }

    try {
      wx.showLoading({ title: '保存中...' });

      // 1. 上传图片到云存储
      const fileID = await this.uploadImageToCloud();

      // 2. 保存灵感到云数据库
      const cloudResult = await this.saveToCloud(fileID);
      
      // 3. 同时保存到本地存储
      this.saveToLocalStorage(cloudResult._id);

      wx.hideLoading();

      // 检查是否是批量导入模式
      if (this.data.isBatch) {
        // 获取全局数据
        const app = getApp();
        if (app.globalData && app.globalData.tempInspirationBatchImages) {
          // 更新当前索引
          const newIndex = this.data.batchCurrentIndex + 1;
          
          // 如果还有更多图片要处理
          if (newIndex < this.data.batchTotal) {
            // 更新界面显示
            this.setData({
              batchCurrentIndex: newIndex,
              // 重置表单数据
              formData: {
                title: '',
                tags: '',
                note: '',
                link: '',
                relatedItems: [],
                relatedOutfits: []
              },
              // 更新图片路径为下一张
              imagePath: app.globalData.tempInspirationBatchImages[newIndex],
              // 清除已上传的云路径
              cloud_image_path: ''
            });
            
            // 更新全局当前图片
            app.globalData.tempInspirationImage = app.globalData.tempInspirationBatchImages[newIndex];
            app.globalData.batchCurrentIndex = newIndex;
            
            // 显示进度提示
            wx.showToast({
              title: `已保存 ${newIndex}/${this.data.batchTotal}`,
              icon: 'success',
              duration: 1500
            });
            
            return; // 不返回上一页，继续处理下一张图片
          } else {
            // 处理完所有图片，清除全局数据
            app.globalData.tempInspirationBatchImages = null;
            app.globalData.tempInspirationImage = null;
            app.globalData.batchCurrentIndex = 0;
            app.globalData.batchImageCount = 0;
            
            // 显示完成提示
            wx.showToast({
              title: `批量添加完成`,
              icon: 'success',
              duration: 1500
            });
          }
        }
      } else {
        // 非批量模式，显示普通成功提示
        wx.showToast({
          title: '保存成功',
          icon: 'success',
          duration: 1500
        });
      }

      // 延迟返回，让用户看到成功提示
      setTimeout(() => {
        wx.navigateBack();
      }, 1500);
    } catch (error) {
      wx.hideLoading();
      wx.showToast({
        title: '保存失败: ' + error.message,
        icon: 'none'
      });
    }
  },

  // 显示分类选择器
  showCategorySelector: function() {
    const app = getApp();
    const categories = app.globalData.inspirationCategories || [];
    
    if (categories.length === 0) {
      // 如果没有可用的分类列表，提示用户创建分类
      wx.showToast({
        title: '请先创建分类',
        icon: 'none'
      });
      return;
    }
    
    // 显示分类选择器
    wx.showActionSheet({
      itemList: categories.map(cat => cat.name),
      success: (res) => {
        const selectedCategory = categories[res.tapIndex];
        this.setData({
          categoryId: selectedCategory.id,
          categoryName: selectedCategory.name
        });
      }
    });
  },

  // 选择分类处理
  selectCategory: function() {
    this.showCategorySelector();
  },

  // 上传图片到云存储
  uploadImageToCloud: async function() {
    if (!this.data.imagePath) {
      throw new Error('没有选择图片');
    }

    try {
      // 提取文件扩展名，如果没有扩展名则默认为jpg
      let extension = 'jpg';
      const extensionMatch = this.data.imagePath.match(/\.(\w+)$/);
      if (extensionMatch && extensionMatch[1]) {
        extension = extensionMatch[1].toLowerCase();
      }
      
      const cloudPath = `inspirations/${Date.now()}-${Math.floor(Math.random() * 1000)}.${extension}`;
      
      const result = await wx.cloud.uploadFile({
        cloudPath: cloudPath,
        filePath: this.data.imagePath
      });
      
      // 保存云路径到data
      this.setData({
        cloud_image_path: result.fileID
      });
      
      console.log('图片上传成功', result.fileID);
      return result.fileID;
    } catch (error) {
      console.error('上传图片到云存储失败:', error);
      throw new Error('上传图片失败');
    }
  },
  
  // 保存灵感到云数据库
  saveToCloud: async function(fileID) {
    try {
      const db = wx.cloud.database();
      
      // 构建灵感数据
      const inspirationData = {
        title: this.data.formData.title || '灵感',
        categoryId: this.data.categoryId,
        categoryName: this.data.categoryName,
        image: fileID,
        tags: this.data.formData.tags,
        note: this.data.formData.note,
        link: this.data.formData.link,
        relatedItems: this.data.formData.relatedItems,
        relatedOutfits: this.data.formData.relatedOutfits,
        createdAt: new Date(),
        updatedAt: new Date()
      };
      
      // 添加到云数据库
      const result = await db.collection('inspirations').add({
        data: inspirationData
      });
      
      console.log('保存灵感到云数据库成功:', result);
      return result;
    } catch (error) {
      console.error('保存灵感到云数据库失败:', error);
      throw new Error('保存到云数据库失败');
    }
  },
  
  // 保存到本地存储
  saveToLocalStorage: function(cloudId) {
    try {
      // 获取当前本地灵感数据
      let inspirations = wx.getStorageSync('inspirations') || {};
      
      // 如果该分类不存在，创建空数组
      if (!inspirations[this.data.categoryId]) {
        inspirations[this.data.categoryId] = [];
      }
      
      // 添加新灵感到对应分类
      inspirations[this.data.categoryId].push({
        id: cloudId,
        cloudId: cloudId,
        title: this.data.formData.title || '灵感',
        image: this.data.cloud_image_path,
        tags: this.data.formData.tags,
        note: this.data.formData.note,
        link: this.data.formData.link,
        createdAt: new Date()
      });
      
      // 保存回本地
      wx.setStorageSync('inspirations', inspirations);
      console.log('保存灵感到本地存储成功');
    } catch (error) {
      console.error('保存灵感到本地存储失败:', error);
      // 本地保存失败不抛出异常，因为云端已经保存成功
    }
  },

  // 选择图片
  chooseImage: function() {
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        const tempFilePath = res.tempFiles[0].tempFilePath;
        this.setData({
          imagePath: tempFilePath
        });
      }
    });
  },
  
  // 新增加载分类数据的方法
  loadCategories: function() {
    try {
      // 从云数据库加载分类
      const db = wx.cloud.database();
      db.collection('inspiration_categories')
        .orderBy('order', 'asc')
        .get()
        .then(res => {
          const categories = res.data.map(item => ({
            id: item._id,
            name: item.name
          }));
          
          // 保存到全局数据以便其他地方使用
          const app = getApp();
          if (!app.globalData) {
            app.globalData = {};
          }
          app.globalData.inspirationCategories = categories;
        })
        .catch(err => {
          console.error('加载分类失败:', err);
        });
    } catch (error) {
      console.error('加载分类发生错误:', error);
    }
  },

  // 选择关联单品
  selectRelatedItems: function() {
    wx.navigateTo({
      url: '/pages/select_items/select_items?selectedItems=' + JSON.stringify(this.data.formData.relatedItems)
    });
  },
  
  // 选择关联搭配
  selectRelatedOutfits: function() {
    wx.navigateTo({
      url: '/pages/select_outfits/select_outfits?selectedOutfits=' + JSON.stringify(this.data.formData.relatedOutfits)
    });
  },
  
  // 回调：接收选择的单品
  onRelatedItemsSelected: function(items) {
    this.setData({
      'formData.relatedItems': items
    });
  },
  
  // 回调：接收选择的搭配
  onRelatedOutfitsSelected: function(outfits) {
    this.setData({
      'formData.relatedOutfits': outfits
    });
  },

  // 监听页面显示
  onShow: function() {
    // 检查是否有通过全局变量传递的选中单品或搭配
    const app = getApp();
    if (app.globalData) {
      // 处理选中的关联单品
      if (app.globalData.selectedRelatedItems) {
        this.setData({
          'formData.relatedItems': app.globalData.selectedRelatedItems
        });
        app.globalData.selectedRelatedItems = null;
      }
      
      // 处理选中的关联搭配
      if (app.globalData.selectedRelatedOutfits) {
        this.setData({
          'formData.relatedOutfits': app.globalData.selectedRelatedOutfits
        });
        app.globalData.selectedRelatedOutfits = null;
      }
    }
  }
});