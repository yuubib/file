Page({
  data: {
    items: [],
    selectedItems: [],
    searchQuery: '',
    loading: true
  },
  
  //=================== 生命周期函数 ===================
  
  onLoad: function(options) {
    // 解析已选择的单品（如果有）
    if (options.selectedItems) {
      try {
        const selectedItems = JSON.parse(options.selectedItems);
        this.setData({
          selectedItems: selectedItems
        });
      } catch (e) {
        wx.showToast({
          title: '解析已选择单品失败',
          icon: 'none'
        });
      }
    }
    
    // 加载所有衣物单品
    this.loadItems();
  },
  
  //=================== 数据加载函数 ===================
  
  // 从云数据库加载衣物单品
  loadItems: function() {
    this.setData({ loading: true });
    
    const db = wx.cloud.database();
    db.collection('clothes')
      .get()
      .then(res => {
        this.setData({
          items: res.data,
          loading: false
        });
      })
      .catch(err => {
        this.setData({ loading: false });
        wx.showToast({
          title: '加载单品失败',
          icon: 'none'
        });
      });
  },
  
  //=================== 单品选择函数 ===================
  
  // 切换单品的选择状态
  toggleItemSelection: function(e) {
    const itemId = e.currentTarget.dataset.id;
    const item = this.data.items.find(i => i._id === itemId);
    
    if (!item) return;
    
    // 检查单品是否已经被选择
    const index = this.data.selectedItems.findIndex(i => i.id === itemId);
    
    if (index > -1) {
      // 单品已被选择，移除它
      const newSelectedItems = [...this.data.selectedItems];
      newSelectedItems.splice(index, 1);
      this.setData({
        selectedItems: newSelectedItems
      });
    } else {
      // 单品未被选择，添加它
      const newSelectedItems = [...this.data.selectedItems];
      newSelectedItems.push({
        id: item._id,
        name: item.name || '单品',
        image: item.images && item.images.length > 0 ? item.images[0] : ''
      });
      this.setData({
        selectedItems: newSelectedItems
      });
    }
  },
  
  // 检查单品是否已被选择
  isItemSelected: function(itemId) {
    return this.data.selectedItems.some(item => item.id === itemId);
  },
  
  //=================== 搜索函数 ===================
  
  // 处理搜索输入
  onSearchInput: function(e) {
    this.setData({
      searchQuery: e.detail.value
    });
  },
  
  //=================== 操作函数 ===================
  
  // 确认选择并返回上一页
  confirmSelection: function() {
    // 将选中的单品传回添加灵感页面
    const app = getApp();
    if (!app.globalData) {
      app.globalData = {};
    }
    
    app.globalData.selectedRelatedItems = this.data.selectedItems;
    wx.navigateBack();
  },
  
  // 取消并返回上一页
  cancelSelection: function() {
    wx.navigateBack();
  }
}); 