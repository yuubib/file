// pages/settings/settings.js
Page({
  data: {
    title: '我的衣橱',
    showDropdown: false,
    wardrobeStats: {
      items: 0,
      outfits: 0,
      calendar: 1,
      inspiration: 0
    },
    settingsList: [
      { id: 'stats', name: '衣橱统计', icon: 'stats', showArrow: true, type: 'stats' },
      // { id: 'member', name: '会员', icon: 'member', showArrow: true, type: 'member', actionText: '升级' },
      // { id: 'backup', name: '数据备份', icon: 'backup', showArrow: true, hasRedDot: true },
      // { id: 'season', name: '限定季节', icon: 'season', showArrow: true, info: '不限季节' },
      // { id: 'wardrobe', name: '管理衣橱', icon: 'wardrobe', showArrow: true },
      // { id: 'options', name: '管理选项', icon: 'options', showArrow: true },
      // { id: 'size', name: '身材尺码', icon: 'size', showArrow: true },
      // { id: 'trash', name: '回收站', icon: 'trash', showArrow: true },
      // { id: 'modules', name: '功能模块', icon: 'modules', showArrow: true },
      { id: 'appearance', name: '外观', icon: 'appearance', showArrow: true, info: '跟随系统' },
      { id: 'help', name: '帮助中心', icon: 'help', showArrow: true },
      // { id: 'feedback', name: '问题反馈', icon: 'feedback', showArrow: true },
      // { id: 'wechat', name: '微信公众号', icon: 'wechat', showArrow: true }
    ]
  },
  
  //=================== 生命周期函数 ===================
  
  onLoad: function() {
    // 加载衣橱统计数据
    this.loadWardrobeStats();
  },
  
  onShow: function() {
    // 刷新衣橱统计数据
    this.loadWardrobeStats();
  },

  //=================== 数据加载函数 ===================
  
  // 加载衣橱统计数据
  loadWardrobeStats: function() {
    wx.showLoading({
      title: '加载中...',
      mask: true
    });
    
    // 获取云数据库实例
    const db = wx.cloud.database();
    
    // 创建一个Promise数组，同时查询各个集合的数量
    const promises = [
      // 查询clothes集合（单品）数量
      db.collection('clothes').count(),
      
      // 查询collages集合（搭配）数量
      db.collection('collages').count(),
      
      // 查询calendar_events集合（日历记录）数量
      db.collection('calendar_events').count().catch(() => ({ total: 0 })),
      
      // 查询inspirations集合（灵感）数量
      db.collection('inspirations').count().catch(() => ({ total: 0 }))
    ];
    
    // 使用Promise.all等待所有查询完成
    Promise.all(promises)
      .then(([clothesRes, collagesRes, calendarRes, inspirationsRes]) => {
        // 更新统计数据
        this.setData({
          'wardrobeStats.items': clothesRes.total || 0,
          'wardrobeStats.outfits': collagesRes.total || 0,
          'wardrobeStats.calendar': calendarRes.total || 0,
          'wardrobeStats.inspiration': inspirationsRes.total || 0
        });
        
        console.log('衣橱统计数据已更新:', {
          单品: clothesRes.total,
          搭配: collagesRes.total,
          日历: calendarRes.total,
          灵感: inspirationsRes.total
        });
        
        wx.hideLoading();
      })
      .catch(err => {
        console.error('获取统计数据失败:', err);
        
        // 获取失败时，尝试从本地存储获取数据作为备选
        const clothItems = wx.getStorageSync('clothItems') || [];
        const outfits = wx.getStorageSync('outfits') || [];
        const calendarEvents = wx.getStorageSync('calendarEvents') || [];
        const inspirations = wx.getStorageSync('inspirations') || {};
        
        // 计算灵感总数
        let inspirationCount = 0;
        for (const key in inspirations) {
          if (Array.isArray(inspirations[key])) {
            inspirationCount += inspirations[key].length;
          }
        }
        
        // 更新状态
        this.setData({
          'wardrobeStats.items': clothItems.length,
          'wardrobeStats.outfits': outfits.length,
          'wardrobeStats.calendar': calendarEvents.length || 0,
          'wardrobeStats.inspiration': inspirationCount
        });
        
        wx.hideLoading();
        
        wx.showToast({
          title: '使用本地统计数据',
          icon: 'none'
        });
      });
  },

  //=================== 设置项操作函数 ===================
  
  // 点击设置项
  onSettingTap: function(e) {
    const settingId = e.currentTarget.dataset.id;
    
    switch(settingId) {
      case 'stats':
        this.showDevelopingFeature('衣橱统计');
        break;
      case 'member':
        this.showDevelopingFeature('会员');
        break;
      case 'backup':
        this.showDevelopingFeature('数据备份');
        break;
      case 'season':
        // 处理季节限制设置
        this.showSeasonOptions();
        break;
      case 'wardrobe':
        this.showDevelopingFeature('衣橱管理');
        break;
      case 'options':
        this.showDevelopingFeature('选项管理');
        break;
      case 'size':
        this.showDevelopingFeature('身材尺码');
        break;
      case 'trash':
        this.showDevelopingFeature('回收站');
        break;
      case 'modules':
        this.showDevelopingFeature('功能模块设置');
        break;
      case 'appearance':
        // 处理外观设置
        this.showAppearanceOptions();
        break;
      case 'help':
        this.showDevelopingFeature('帮助中心');
        break;
      case 'feedback':
        this.showDevelopingFeature('问题反馈');
        break;
      case 'wechat':
        this.showDevelopingFeature('微信公众号');
        break;
    }
  },
  
  // 显示正在开发中的功能提示
  showDevelopingFeature: function(featureName) {
    wx.showToast({ 
      title: `${featureName}功能开发中`, 
      icon: 'none' 
    });
  },
  
  // 显示季节选项
  showSeasonOptions: function() {
    wx.showActionSheet({
      itemList: ['不限季节', '春季', '夏季', '秋季', '冬季'],
      success: (res) => {
        if (res.tapIndex >= 0) {
          const seasons = ['不限季节', '春季', '夏季', '秋季', '冬季'];
          const selectedSeason = seasons[res.tapIndex];
          
          // 更新设置项的显示
          const settingsList = this.data.settingsList;
          const index = settingsList.findIndex(item => item.id === 'season');
          if (index >= 0) {
            settingsList[index].info = selectedSeason;
            this.setData({ settingsList });
          }
          
          // 保存设置
          wx.setStorageSync('selectedSeason', selectedSeason);
        }
      }
    });
  },
  
  // 显示外观选项
  showAppearanceOptions: function() {
    wx.showActionSheet({
      itemList: ['跟随系统', '浅色模式', '深色模式'],
      success: (res) => {
        if (res.tapIndex >= 0) {
          const appearances = ['跟随系统', '浅色模式', '深色模式'];
          const selectedAppearance = appearances[res.tapIndex];
          
          // 更新设置项的显示
          const settingsList = this.data.settingsList;
          const index = settingsList.findIndex(item => item.id === 'appearance');
          if (index >= 0) {
            settingsList[index].info = selectedAppearance;
            this.setData({ settingsList });
          }
          
          // 保存设置
          wx.setStorageSync('appearance', selectedAppearance);
        }
      }
    });
  },

  //=================== 衣橱切换功能 ===================
  
  // 添加下拉菜单切换方法
  toggleDropdown: function() {
    this.setData({
      showDropdown: !this.data.showDropdown
    });
  },
  
  // 关闭衣橱切换弹窗
  closeWardrobePopup: function() {
    this.setData({
      showDropdown: false
    });
  },
  
  // 阻止事件冒泡
  stopPropagation: function(e) {
    // 阻止事件冒泡
    return false;
  },
  
  // 选择衣橱
  selectWardrobe: function(e) {
    const wardrobeId = e.currentTarget.dataset.id;
    
    // 关闭弹窗
    this.closeWardrobePopup();
    
    // 这里可以添加衣橱切换的逻辑
    this.showDevelopingFeature('切换衣橱');
  },
  
  // 衣橱设置
  wardrobeSettings: function() {
    this.showDevelopingFeature('衣橱设置');
  },
  
  // 添加衣橱
  addWardrobe: function() {
    this.showDevelopingFeature('添加衣橱');
  },
  
  //=================== 用户信息功能 ===================
  
  // 用户资料
  goToUserProfile: function() {
    this.showDevelopingFeature('用户资料');
  },
  
  // 关于页面
  goToAbout: function() {
    wx.navigateTo({
      url: '/pages/about/about'
    });
  }
}); 