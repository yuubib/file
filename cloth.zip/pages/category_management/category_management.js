const app = getApp()

Page({
  data: {
    categories: [],
    showCustomMenu: false,
    customMenuPosition: '',
    selectedCategoryId: null,
    pageType: 'clothes', // 默认为衣物分类，可选值: 'clothes' 或 'outfit'
    pageTitle: '管理分类'
  },
  
  onLoad: function(options) {
    // 根据参数决定显示单品分类还是搭配分类
    if (options.type === 'outfit') {
      this.setData({
        pageType: 'outfit',
        pageTitle: '管理搭配分类'
      });
    } else {
      this.setData({
        pageType: 'clothes',
        pageTitle: '管理单品分类'
      });
    }
    
    this.loadCategories();
  },
  
  // 加载分类数据
  loadCategories: async function() {
    try {
      const db = wx.cloud.database();
      let categoriesCollection;
      let itemsCollection;
      
      // 根据页面类型决定使用哪个集合
      if (this.data.pageType === 'outfit') {
        categoriesCollection = db.collection('outfit_categories');
        itemsCollection = db.collection('collages');
      } else {
        categoriesCollection = db.collection('categories');
        itemsCollection = db.collection('clothes');
      }
      
      // 获取所有分类，按照 order 字段排序
      const { data: categories } = await categoriesCollection
        .orderBy('order', 'asc')
        .get();
      
      // 从对应集合中获取每个分类的实际计数
      const { data: items } = await itemsCollection.get();
      
      // 更新每个分类的数量
      const updatedCategories = categories.map(category => {
        const count = items.filter(item => item.categoryId === category._id).length;
        return { ...category, count };
      });
      
      this.setData({ categories: updatedCategories });
      
      // 更新数据库中的count值以保持同步
      for (const category of updatedCategories) {
        const originalCategory = categories.find(c => c._id === category._id);
        if (category.count !== originalCategory.count) {
          await categoriesCollection.doc(category._id).update({
            data: {
              count: category.count,
              updateTime: db.serverDate()
            }
          });
        }
      }
    } catch (error) {
      console.error('加载分类失败：', error);
      wx.showToast({
        title: '加载分类失败',
        icon: 'none'
      });
    }
  },
  
  // 添加分类
  addCategory: function() {
    wx.showModal({
      title: '添加分类',
      content: '请输入分类名称',
      editable: true,
      placeholderText: '新分类名称',
      success: async (res) => {
        if (res.confirm && res.content) {
          try {
            const db = wx.cloud.database();
            const categoriesCollection = this.data.pageType === 'outfit' ? 
              db.collection('outfit_categories') : db.collection('categories');
            
            // 获取当前最大的 order 值
            const { data: lastCategory } = await categoriesCollection
              .orderBy('order', 'desc')
              .limit(1)
              .get();
            
            const newOrder = lastCategory.length > 0 ? lastCategory[0].order + 1 : 0;
            
            // 创建新分类
            await categoriesCollection.add({
              data: {
                name: res.content,
                count: 0,
                order: newOrder,
                createTime: db.serverDate(),
                updateTime: db.serverDate()
              }
            });
            
            // 重新加载分类列表
            this.loadCategories();
            
            wx.showToast({
              title: '添加成功',
              icon: 'success'
            });
          } catch (error) {
            console.error('添加分类失败：', error);
            wx.showToast({
              title: '添加失败',
              icon: 'none'
            });
          }
        }
      }
    });
  },
  
  // 编辑分类
  handleEditAction: async function() {
    const categoryId = this.data.selectedCategoryId;
    const category = this.data.categories.find(c => c._id === categoryId);
    
    if (!category) {
      this.closeCustomMenu();
      return;
    }
    
    wx.showModal({
      title: '编辑分类',
      content: '请输入新的分类名称',
      editable: true,
      placeholderText: category.name,
      success: async (res) => {
        if (res.confirm && res.content) {
          try {
            const db = wx.cloud.database();
            const categoriesCollection = this.data.pageType === 'outfit' ? 
              db.collection('outfit_categories') : db.collection('categories');
            
            await categoriesCollection.doc(categoryId).update({
              data: {
                name: res.content,
                updateTime: db.serverDate()
              }
            });
            
            // 重新加载分类列表
            this.loadCategories();
            
            wx.showToast({
              title: '更新成功',
              icon: 'success'
            });
          } catch (error) {
            console.error('更新分类失败：', error);
            wx.showToast({
              title: '更新失败',
              icon: 'none'
            });
          }
        }
        this.closeCustomMenu();
      }
    });
  },
  
  // 删除分类
  handleDeleteAction: async function() {
    const categoryId = this.data.selectedCategoryId;
    
    wx.showModal({
      title: '删除分类',
      content: '确定要删除这个分类吗？删除后无法恢复。',
      success: async (res) => {
        if (res.confirm) {
          try {
            const db = wx.cloud.database();
            const categoriesCollection = this.data.pageType === 'outfit' ? 
              db.collection('outfit_categories') : db.collection('categories');
            
            await categoriesCollection.doc(categoryId).remove();
            
            // 重新加载分类列表
            this.loadCategories();
            
            wx.showToast({
              title: '删除成功',
              icon: 'success'
            });
          } catch (error) {
            console.error('删除分类失败：', error);
            wx.showToast({
              title: '删除失败',
              icon: 'none'
            });
          }
        }
        this.closeCustomMenu();
      }
    });
  },
  
  // 显示编辑菜单
  showEditMenu: function(e) {
    const categoryId = e.currentTarget.dataset.id;
    const index = e.currentTarget.dataset.index;
    
    // 获取点击按钮的位置信息
    const query = wx.createSelectorQuery();
    query.select('#more-btn-' + index).boundingClientRect();
    query.exec((res) => {
      if (res[0]) {
        const buttonRect = res[0];
        const menuPosition = `left: ${buttonRect.left}px; top: ${buttonRect.top + buttonRect.height}px;`;
        
        this.setData({
          showCustomMenu: true,
          customMenuPosition: menuPosition,
          selectedCategoryId: categoryId
        });
      }
    });
  },
  
  // 关闭菜单
  closeCustomMenu: function() {
    this.setData({
      showCustomMenu: false
    });
  },
  
  // 阻止事件冒泡
  stopPropagation: function() {
    // 空函数，仅用于阻止事件冒泡
  },
  
  // 返回上一页
  goBack: function() {
    wx.navigateBack();
  },
  
  // 导航到子分类页面
  navigateToSubcategory: function(e) {
    const categoryId = e.currentTarget.dataset.id;
    const categoryName = e.currentTarget.dataset.name;
    
    wx.navigateTo({
      url: `/pages/subcategory/subcategory?categoryId=${categoryId}&categoryName=${encodeURIComponent(categoryName)}`
    });
  },
  
  // 导航到搭配列表页面
  navigateToOutfits: function(e) {
    const categoryId = e.currentTarget.dataset.id;
    const categoryName = e.currentTarget.dataset.name;
    
    wx.navigateTo({
      url: `/pages/outfit_list/outfit_list?categoryId=${categoryId}&categoryName=${encodeURIComponent(categoryName)}`
    });
  }
}); 