const app = getApp()

Page({
  data: {
    parentId: null,
    parentName: '',
    subcategories: [],
    showCustomMenu: false,
    customMenuPosition: '',
    selectedSubcategoryId: null,
    pageType: 'clothes' // 默认为衣物分类
  },
  
  //=================== 生命周期函数 ===================
  
  onLoad: function(options) {
    if (options.parentId && options.parentName) {
      // 设置分类类型
      const pageType = options.type === 'outfit' ? 'outfit' : 'clothes';
      
      this.setData({
        parentId: options.parentId,
        parentName: decodeURIComponent(options.parentName),
        pageType: pageType
      });
      
      // 加载子分类数据
      this.loadSubcategories();
    } else {
      wx.showToast({
        title: '缺少必要参数',
        icon: 'none'
      });
      setTimeout(() => {
        wx.navigateBack();
      }, 1500);
    }
  },
  
  //=================== 数据加载函数 ===================
  
  // 加载子分类数据
  loadSubcategories: async function() {
    wx.showLoading({ title: '加载中...' });
    
    try {
      const db = wx.cloud.database();
      let subcategoriesCollection;
      let itemsCollection;
      
      // 根据页面类型选择集合
      if (this.data.pageType === 'outfit') {
        subcategoriesCollection = db.collection('outfit_subcategories');
        itemsCollection = db.collection('collages');
      } else {
        subcategoriesCollection = db.collection('subcategories');
        itemsCollection = db.collection('clothes');
      }
      
      // 获取指定父分类下的所有子分类，按照 order 字段排序
      const { data: subcategories } = await subcategoriesCollection
        .where({
          parentId: this.data.parentId
        })
        .orderBy('order', 'asc')
        .get();
      
      // 对于每个子分类，加载示例图片
      const enhancedSubcategories = await this.loadSubcategoriesWithImages(subcategories, itemsCollection);
      
      this.setData({ subcategories: enhancedSubcategories });
      wx.hideLoading();
    } catch (error) {
      wx.hideLoading();
      wx.showToast({
        title: '加载子分类失败',
        icon: 'none'
      });
    }
  },
  
  // 为子分类加载示例图片
  loadSubcategoriesWithImages: async function(subcategories, itemsCollection) {
    try {
      if (!subcategories || subcategories.length === 0) return subcategories;
      
      const db = wx.cloud.database();
      const _ = db.command;
      
      const enhancedSubcategories = [];
      
      // 为每个子分类获取一张示例图片
      for (const subcategory of subcategories) {
        try {
          let image = '';
          // 获取该子分类下的一个衣物作为示例
          if (subcategory.count > 0) {
            const { data: clothItems } = await db.collection('clothes')
              .where({
                subcategoryId: subcategory._id
              })
              .limit(1)
              .get();
            
            if (clothItems && clothItems.length > 0 && clothItems[0].image) {
              image = clothItems[0].image;
              
              // 验证图片链接是否可用
              try {
                // 预处理图片链接，确保它是有效的云存储文件ID
                if (image && !image.startsWith('cloud://') && !image.startsWith('http')) {
                  image = '';
                }
              } catch (error) {
                image = '';
              }
            }
          }
          
          enhancedSubcategories.push({
            ...subcategory,
            image: image || '/images/default_clothes.png' // 确保始终有默认图片
          });
        } catch (e) {
          // 如果获取失败，仍添加子分类，但使用默认图片
          enhancedSubcategories.push({
            ...subcategory,
            image: '/images/default_clothes.png'
          });
        }
      }
      
      return enhancedSubcategories;
    } catch (error) {
      // 设置默认图片
      return subcategories.map(subcategory => ({
        ...subcategory,
        image: '/images/default_clothes.png'
      }));
    }
  },
  
  //=================== 子分类操作函数 ===================
  
  // 添加子分类
  addSubcategory: async function() {
    wx.showModal({
      title: '添加子分类',
      content: '请输入子分类名称',
      editable: true,
      placeholderText: '新子分类名称',
      success: async (res) => {
        if (res.confirm && res.content) {
          try {
            const db = wx.cloud.database();
            const subcategoriesCollection = this.data.pageType === 'outfit' 
              ? db.collection('outfit_subcategories') 
              : db.collection('subcategories');
            
            // 获取当前最大的 order 值
            const { data: lastSubcategory } = await subcategoriesCollection
              .where({
                parentId: this.data.parentId
              })
              .orderBy('order', 'desc')
              .limit(1)
              .get();
            
            const newOrder = lastSubcategory.length > 0 ? lastSubcategory[0].order + 1 : 0;
            
            // 创建新子分类
            const result = await subcategoriesCollection.add({
              data: {
                name: res.content,
                parentId: this.data.parentId,
                count: 0,
                order: newOrder,
                createTime: db.serverDate(),
                updateTime: db.serverDate()
              }
            });
            
            // 添加新创建的子分类到当前列表显示
            const newSubcategories = [...this.data.subcategories, {
              _id: result._id,
              name: res.content,
              parentId: this.data.parentId,
              count: 0,
              order: newOrder,
              image: '/images/default_clothes.png', // 新增的子分类使用默认图片
              createTime: new Date(),
              updateTime: new Date()
            }];
            
            this.setData({
              subcategories: newSubcategories.sort((a, b) => a.order - b.order)
            });
            
            wx.showToast({
              title: '添加成功',
              icon: 'success'
            });
          } catch (error) {
            wx.showToast({
              title: '添加失败',
              icon: 'none'
            });
          }
        }
      }
    });
  },
  
  //=================== 编辑菜单相关函数 ===================
  
  // 显示编辑菜单
  showEditMenu: function(e) {
    const subcategoryId = e.currentTarget.dataset.id;
    const rect = e.currentTarget.getBoundingClientRect();
    
    this.setData({
      showCustomMenu: true,
      customMenuPosition: `left: ${rect.right}px; top: ${rect.top}px;`,
      selectedSubcategoryId: subcategoryId
    });
  },
  
  // 关闭编辑菜单
  closeCustomMenu: function() {
    this.setData({
      showCustomMenu: false,
      selectedSubcategoryId: null
    });
  },
  
  // 编辑子分类
  handleEditAction: async function() {
    const subcategoryId = this.data.selectedSubcategoryId;
    const subcategoryIndex = this.data.subcategories.findIndex(s => s._id === subcategoryId);
    
    if (subcategoryIndex === -1) {
      this.closeCustomMenu();
      return;
    }
    
    const subcategory = this.data.subcategories[subcategoryIndex];
    
    wx.showModal({
      title: '编辑子分类',
      content: '请输入新的子分类名称',
      editable: true,
      placeholderText: subcategory.name,
      success: async (res) => {
        if (res.confirm && res.content) {
          wx.showLoading({ title: '更新中...' });
          
          try {
            const db = wx.cloud.database();
            const subcategoriesCollection = this.data.pageType === 'outfit' 
              ? db.collection('outfit_subcategories') 
              : db.collection('subcategories');
            
            // 更新子分类名称
            await subcategoriesCollection.doc(subcategoryId).update({
              data: {
                name: res.content,
                updateTime: db.serverDate()
              }
            });
            
            // 更新本地数据
            const newSubcategories = [...this.data.subcategories];
            newSubcategories[subcategoryIndex].name = res.content;
            newSubcategories[subcategoryIndex].updateTime = new Date();
            
            this.setData({
              subcategories: newSubcategories
            });
            
            wx.hideLoading();
            wx.showToast({
              title: '更新成功',
              icon: 'success'
            });
          } catch (error) {
            wx.hideLoading();
            wx.showToast({
              title: '更新失败',
              icon: 'none'
            });
          }
        }
        
        this.closeCustomMenu();
      }
    });
  },
  
  // 删除子分类
  handleDeleteAction: async function() {
    const subcategoryId = this.data.selectedSubcategoryId;
    const subcategoryIndex = this.data.subcategories.findIndex(s => s._id === subcategoryId);
    
    if (subcategoryIndex === -1) {
      this.closeCustomMenu();
      return;
    }
    
    const subcategory = this.data.subcategories[subcategoryIndex];
    
    // 显示删除确认对话框
    wx.showModal({
      title: '确认删除',
      content: `确定要删除子分类"${subcategory.name}"吗？`,
      success: async (res) => {
        if (res.confirm) {
          wx.showLoading({ title: '删除中...' });
          
          try {
            const db = wx.cloud.database();
            const subcategoriesCollection = this.data.pageType === 'outfit' 
              ? db.collection('outfit_subcategories') 
              : db.collection('subcategories');
            
            // 删除子分类
            await subcategoriesCollection.doc(subcategoryId).remove();
            
            // 更新本地数据
            const newSubcategories = this.data.subcategories.filter(s => s._id !== subcategoryId);
            
            this.setData({
              subcategories: newSubcategories
            });
            
            wx.hideLoading();
            wx.showToast({
              title: '删除成功',
              icon: 'success'
            });
          } catch (error) {
            wx.hideLoading();
            wx.showToast({
              title: '删除失败',
              icon: 'none'
            });
          }
        }
        
        this.closeCustomMenu();
      }
    });
  },
  
  //=================== 导航与交互函数 ===================
  
  // 返回上一页
  goBack: function() {
    wx.navigateBack();
  },
  
  // 阻止事件冒泡
  stopPropagation: function(e) {
    return false;
  },
  
  // 跳转到子分类下的衣物列表页面
  navigateToItems: function(e) {
    const subcategoryId = e.currentTarget.dataset.id;
    const subcategoryName = e.currentTarget.dataset.name;
    
    // 跳转到相应的列表页
    if (this.data.pageType === 'outfit') {
      wx.navigateTo({
        url: `/pages/outfits/outfits?subcategoryId=${subcategoryId}&subcategoryName=${subcategoryName}`
      });
    } else {
      wx.navigateTo({
        url: `/pages/items/items?subcategoryId=${subcategoryId}&subcategoryName=${subcategoryName}`
      });
    }
  }
}); 