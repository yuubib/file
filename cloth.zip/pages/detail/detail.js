Page({
  data: {
    title: '我的衣橱',
    showDropdown: false,
    year: 2025,
    month: 3,
    day: 15,
    selectedDate: '2025-03-15',
    weekdays: ['日', '一', '二', '三', '四', '五', '六'],
    dateList: [],
    records: {}, // 存储日期对应的记录
    
    // 日期选择器相关
    showDatePicker: false,
    yearArray: [],
    monthArray: [],
    dayArray: [],
    pickerValue: [0, 0, 0],
    
    // 操作菜单
    showActionMenu: false
  },
  
  onLoad: function () {
    // 初始化当前日期
    const now = new Date();
    const currentYear = 2025; // 根据图片设置为2025年
    const currentMonth = 3; // 根据图片设置为3月
    const currentDay = 15; // 根据图片设置为15日
    
    // 初始化日期选择器数据
    this.initDatePickerData(currentYear, currentMonth, currentDay);
    
    this.setData({
      year: currentYear,
      month: currentMonth,
      day: currentDay,
      selectedDate: `${currentYear}-${this.formatNumber(currentMonth)}-${this.formatNumber(currentDay)}`
    });
    
    // 生成日历数据
    this.generateDateList();
  },
  
  onShow: function () {
    // 从本地存储获取记录数据
    const records = wx.getStorageSync('calendarRecords') || {};
    this.setData({ records });
  },
  
  // 生成日历数据
  generateDateList: function () {
    const { year, month } = this.data;
    const dateList = [];
    
    // 获取当月第一天和最后一天
    const firstDay = new Date(year, month - 1, 1);
    const lastDay = new Date(year, month, 0);
    
    // 获取当月第一天是星期几和当月的总天数
    const firstDayWeek = firstDay.getDay();
    const totalDays = lastDay.getDate();
    
    // 获取上个月的最后几天
    const lastMonthLastDay = new Date(year, month - 1, 0).getDate();
    
    // 填充日历数组，一个月的数据用二维数组表示，每行代表一个星期
    let dayCount = 1;
    let nextMonthDay = 1;
    
    // 按周填充日历
    for (let week = 0; week < 6; week++) {
      const weekDays = [];
      for (let day = 0; day < 7; day++) {
        let dateObj;
        
        if (week === 0 && day < firstDayWeek) {
          // 上个月的日期
          const prevMonthDay = lastMonthLastDay - (firstDayWeek - day - 1);
          const prevMonth = month === 1 ? 12 : month - 1;
          const prevYear = month === 1 ? year - 1 : year;
          dateObj = {
            year: prevYear,
            month: prevMonth,
            day: prevMonthDay,
            date: `${prevYear}-${this.formatNumber(prevMonth)}-${this.formatNumber(prevMonthDay)}`,
            currentMonth: false,
            isToday: false,
            selected: false
          };
        } else if (dayCount <= totalDays) {
          // 当月的日期
          dateObj = {
            year: year,
            month: month,
            day: dayCount,
            date: `${year}-${this.formatNumber(month)}-${this.formatNumber(dayCount)}`,
            currentMonth: true,
            isToday: this.isToday(year, month, dayCount),
            selected: dayCount === this.data.day
          };
          dayCount++;
        } else {
          // 下个月的日期
          const nextMonth = month === 12 ? 1 : month + 1;
          const nextYear = month === 12 ? year + 1 : year;
          dateObj = {
            year: nextYear,
            month: nextMonth,
            day: nextMonthDay,
            date: `${nextYear}-${this.formatNumber(nextMonth)}-${this.formatNumber(nextMonthDay)}`,
            currentMonth: false,
            isToday: false,
            selected: false
          };
          nextMonthDay++;
        }
        
        weekDays.push(dateObj);
      }
      dateList.push(weekDays);
      
      // 如果已经填完了当月所有日期和下个月的前几天，就不再继续循环
      if (dayCount > totalDays && week >= 4) {
        break;
      }
    }
    
    this.setData({ dateList });
  },
  
  // 判断是否是今天
  isToday: function (year, month, day) {
    const today = new Date();
    return year === today.getFullYear() && month === today.getMonth() + 1 && day === today.getDate();
  },
  
  // 选择日期
  selectDate: function (e) {
    const { date } = e.currentTarget.dataset;
    const [year, month, day] = date.split('-').map(item => parseInt(item));
    
    // 如果选择的是上个月或下个月的日期，则切换到对应月份
    if (month !== this.data.month) {
      this.setData({
        year,
        month,
        day: parseInt(day)
      }, () => {
        this.generateDateList();
      });
    } else {
      // 更新选中状态
      this.setData({
        day: parseInt(day),
        selectedDate: date
      });
      
      // 更新日历数据中的选中状态
      const dateList = this.data.dateList;
      dateList.forEach(week => {
        week.forEach(dateObj => {
          dateObj.selected = dateObj.date === date;
        });
      });
      
      this.setData({ dateList });
    }
  },
  
  // 初始化日期选择器数据
  initDatePickerData: function(year, month, day) {
    // 生成年份数组，从2025年到2030年
    const yearArray = [2025, 2026, 2027, 2028, 2029, 2030];
    
    // 生成月份数组，从1月到12月
    const monthArray = [];
    for (let i = 1; i <= 12; i++) {
      monthArray.push(i);
    }
    
    // 生成天数数组，根据选中的年月生成对应的天数
    const dayArray = this.getDaysInMonth(year, month);
    
    // 设置picker的默认值
    let yearIndex = yearArray.indexOf(year);
    if (yearIndex === -1) yearIndex = 0;
    
    let monthIndex = month - 1;
    let dayIndex = day - 1;
    
    this.setData({
      yearArray,
      monthArray,
      dayArray,
      pickerValue: [yearIndex, monthIndex, dayIndex]
    });
  },
  
  // 获取某个月的天数
  getDaysInMonth: function(year, month) {
    const days = new Date(year, month, 0).getDate();
    const dayArray = [];
    for (let i = 1; i <= days; i++) {
      dayArray.push(i);
    }
    return dayArray;
  },
  
  // 显示/隐藏日期选择器
  showDatePicker: function() {
    this.setData({ showDatePicker: true });
  },
  
  // 日期选择器变化事件
  onPickerChange: function(e) {
    const values = e.detail.value;
    const year = this.data.yearArray[values[0]];
    const month = this.data.monthArray[values[1]];
    
    // 当年月变化时，需要重新计算该月的天数
    if (year !== this.data.yearArray[this.data.pickerValue[0]] || 
        month !== this.data.monthArray[this.data.pickerValue[1]]) {
      const dayArray = this.getDaysInMonth(year, month);
      
      // 如果选中的日期超过了新月份的天数，则调整为新月份的最后一天
      let dayIndex = values[2];
      if (dayIndex >= dayArray.length) {
        dayIndex = dayArray.length - 1;
      }
      
      this.setData({
        dayArray,
        pickerValue: [values[0], values[1], dayIndex]
      });
    } else {
      this.setData({ pickerValue: values });
    }
  },
  
  // 确认日期选择
  confirmDatePicker: function() {
    const values = this.data.pickerValue;
    const year = this.data.yearArray[values[0]];
    const month = this.data.monthArray[values[1]];
    const day = this.data.dayArray[values[2]];
    
    this.setData({
      year,
      month,
      day,
      selectedDate: `${year}-${this.formatNumber(month)}-${this.formatNumber(day)}`,
      showDatePicker: false
    }, () => {
      this.generateDateList();
    });
  },
  
  // 显示操作菜单
  showActionMenu: function() {
    this.setData({ showActionMenu: true });
  },
  
  // 隐藏操作菜单
  hideActionMenu: function() {
    this.setData({ showActionMenu: false });
  },
  
  // 添加记录通用处理
  addRecord: function (type) {
    this.hideActionMenu();
    
    // 根据类型执行不同操作
    switch(type) {
      case 'outfit':
        wx.navigateTo({ url: '../index/index' });
        break;
      case 'item': 
        wx.navigateTo({ url: '../wardrobe/wardrobe' });
        break;
      default:
        wx.showToast({
          title: `${type}功能开发中`,
          icon: 'none'
        });
    }
  },
  
  // 以下是菜单项点击事件处理
  addWeather: function() {
    this.addRecord('天气记录');
  },
  
  addDiary: function() {
    this.addRecord('日记');
  },
  
  addOutfit: function() {
    this.addRecord('outfit');
  },
  
  addItem: function() {
    this.addRecord('item');
  },
  
  // 格式化数字，个位数前补0
  formatNumber: function (n) {
    n = n.toString();
    return n[1] ? n : '0' + n;
  },
  
  // 显示/隐藏标题栏下拉菜单
  toggleDropdown: function() {
    this.setData({
      showDropdown: !this.data.showDropdown
    });
  },
  
  // 关闭衣橱切换弹窗
  closeWardrobePopup: function() {
    this.setData({ showDropdown: false });
  },
  
  // 阻止事件冒泡
  stopPropagation: function() {
    return false;
  },
  
  // 选择衣橱
  selectWardrobe: function() {
    this.closeWardrobePopup();
    wx.showToast({
      title: '切换衣橱功能开发中',
      icon: 'none'
    });
  },
  
  // 添加衣橱
  addWardrobe: function() {
    wx.showToast({
      title: '创建衣橱功能开发中',
      icon: 'none'
    });
  },
  
  // 衣橱设置
  wardrobeSettings: function() {
    wx.showToast({
      title: '衣橱设置功能开发中',
      icon: 'none'
    });
  }
}) 